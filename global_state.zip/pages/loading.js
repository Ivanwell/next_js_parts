export default function Loading() {
  return <h1>Завантаження...</h1>;
}
