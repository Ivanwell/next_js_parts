import styles from '../styles/Preloader.module.css'

const Preloader = () => {
  return (
    <h1 className={styles.red_back}>
      <div className={styles.text}>BayrakParts</div>
    </h1>
  )
}

export default Preloader
