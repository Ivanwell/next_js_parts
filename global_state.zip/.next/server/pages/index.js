(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405,2197];
exports.modules = {

/***/ 5735:
/***/ ((module) => {

// Exports
module.exports = {
	"container_for_items_row": "Category_in_main_container_for_items_row__bedXG",
	"category_cont": "Category_in_main_category_cont__VF_rp"
};


/***/ }),

/***/ 8502:
/***/ ((module) => {

// Exports
module.exports = {
	"main_container": "Newmainoage_main_container___CRGM",
	"container_for_search_and_promo": "Newmainoage_container_for_search_and_promo__PR4hy",
	"search_form": "Newmainoage_search_form__bwZU_",
	"container_search_form": "Newmainoage_container_search_form__t_KsX",
	"select_car_title": "Newmainoage_select_car_title__yOD43",
	"select_container": "Newmainoage_select_container__lfhXx",
	"container_for_brands": "Newmainoage_container_for_brands___rsSH",
	"number": "Newmainoage_number__eSsUy",
	"search_button": "Newmainoage_search_button__97UpU",
	"cannot_find_part": "Newmainoage_cannot_find_part__a2CEW",
	"cannot_find_part_title": "Newmainoage_cannot_find_part_title__4GCVS",
	"promo_container": "Newmainoage_promo_container__ZsIIs",
	"container_for_items_row": "Newmainoage_container_for_items_row__wWkG_",
	"error_form": "Newmainoage_error_form__uuNlV",
	"why_we": "Newmainoage_why_we___RWK7",
	"our_descr": "Newmainoage_our_descr__ga2PD",
	"our_desc1": "Newmainoage_our_desc1__RXYcE",
	"our_desc2": "Newmainoage_our_desc2__rDFzy",
	"category_link_cont": "Newmainoage_category_link_cont__D4D2T",
	"category_link": "Newmainoage_category_link__TswaE"
};


/***/ }),

/***/ 5401:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5735);
/* harmony import */ var _styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);



const CategoryInMain = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().container_for_items_row),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/filtry-komplektuyuchi",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Деталі для ТО"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/detali-dlya-to-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/amortyzatsiya",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Амортизатори"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/amortyzator.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/systema-oholodzhennya",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Система охолодження"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/systema-oholodzennya-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/shasi",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Ходова частина"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/hodova-chastyna-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/dvygun",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Двигун"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/dvygun-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/aksesuary-zasoby-po-doglyadu-dod.tovary",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Аксесуари"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/aksesuary-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/elektryka",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Електричні частини"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/electryka-min.png",
                        loading: "lazy"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: "/categories/pryvid",
                className: (_styles_Category_in_main_module_css__WEBPACK_IMPORTED_MODULE_2___default().category_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Трансмісія"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://bayrakparts.com/media/transmision1-min.png",
                        loading: "lazy"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryInMain);


/***/ }),

/***/ 6616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8502);
/* harmony import */ var _styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4761);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_category_in_main_category_in_main__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5401);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3291);
/* harmony import */ var _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1639);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8132);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_useragent__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_redux__WEBPACK_IMPORTED_MODULE_7__, _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__]);
([react_redux__WEBPACK_IMPORTED_MODULE_7__, _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const NewMainPage = ({ userAgent  })=>{
    let ua;
    if (userAgent.uaString) {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_9__.useUserAgent)(userAgent.uaString);
    } else {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_9__.useUserAgent)(window.navigator.userAgent);
    }
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [errorForm, setErrorForm] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const formNewData = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.dataForSelects);
    const choosenBrand = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.brand);
    const choosenModel = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.model);
    const choosenCategory = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.category);
    const choosenPart = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.part);
    const loadingFromData = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.dataSelectscartReducer.value.loading);
    const submitingSearch = (e)=>{
        e.preventDefault();
        if (!choosenBrand || !choosenModel || !choosenCategory || !choosenPart) {
            setErrorForm(true);
        } else {
            setErrorForm(false);
            const article = choosenPart + " " + choosenBrand + " " + choosenModel;
            router.push(`/search/${article}`);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!formNewData) {
            const abortController = new AbortController();
            const { signal  } = abortController;
            const apiCall = async ()=>{
                try {
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setLoadingData */ .dm)(true));
                    const res = await fetch(`http://api.bonapart.pro/getSearchCatParts`, {
                        method: "GET",
                        signal: signal
                    });
                    const body = await res.json();
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setDataForForm */ ._1)(body[0].partsData));
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setLoadingData */ .dm)(false));
                } catch (error) {
                    if (!signal?.aborted) {
                        console.error(error);
                        dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setLoadingData */ .dm)(false));
                    }
                }
            };
            apiCall();
            return ()=>{
                abortController.abort();
            };
        } else {}
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_container),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_6___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "BayrakParts || Запчастини з гарантією "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Купити запчастини дешево з гарантією Львів, Київ, Тернопіль, Ужгород, Луцьк, Рівне, Житомир Hyundai/KIA, Хюндай , Toyota/Lexus, Тойота/Лексус, Nissan, Ніссан, Mazda, Мазда, Honda, Хонда, Subaru, Субару, BMW, БМВ,  Volkswagen, Фольксваген. Купити запчастини до ходової частини, двигуна, кузову, трансмісія, комплекти для ТО, комплект ГРМ, водяна помпа, масло, фільтр, амортизатор, сайлентблок. В наявності більше 50000 запчастин. Відправляємо в день замовлення."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "theme-color",
                        content: "#f37c2e"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_for_search_and_promo),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_form),
                        onSubmit: (e)=>submitingSearch(e),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_search_form),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_car_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .search */ .XP,
                                            "Виберіть Ваше авто для пошуку запчастин"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                children: "1"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                value: choosenBrand,
                                                onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setBrand */ .HB)(e.target.value)),
                                                children: [
                                                    !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Оберіть марку"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Завантаження..."
                                                    }),
                                                    formNewData ? formNewData.brands.map((brand)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            children: brand
                                                        })) : null
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                children: "2"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                value: choosenModel,
                                                onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setModel */ .j1)(e.target.value)),
                                                children: [
                                                    !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Оберіть модель"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Завантаження..."
                                                    }),
                                                    choosenBrand ? formNewData.models.find((product)=>product.brandName === choosenBrand).Models.map((model1)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: model1,
                                                            children: model1
                                                        })) : null
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                children: "3"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                value: choosenCategory,
                                                onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setCategory */ .PR)(e.target.value)),
                                                children: [
                                                    !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Оберіть категорію"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Завантаження..."
                                                    }),
                                                    choosenModel ? formNewData.categories.map((categori)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: categori,
                                                            children: categori
                                                        })) : null
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                children: "4"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_8__/* .setPart */ .rx)(e.target.value)),
                                                value: choosenPart,
                                                children: [
                                                    !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Оберіть запчастину"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        selected: true,
                                                        children: "Завантаження..."
                                                    }),
                                                    choosenCategory ? formNewData.exactParts.find((castogory)=>castogory.catigory === choosenCategory).Models.map((part)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: part,
                                                            children: part
                                                        })) : null
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_button),
                                        type: "submit",
                                        children: "Пошук"
                                    })
                                ]
                            }),
                            errorForm ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().error_form),
                                children: "Заповніть усі дані"
                            }) : null,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/leave_request",
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().cannot_find_part),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().cannot_find_part_title),
                                    children: "Не вдається знайти запчастину? Ми допоможемо!"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().promo_container),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "https://bayrakparts.com/media/%D0%9F%D1%96%D0%B4%D0%B3%D0%BE%D1%82%D1%83%D0%B9%D1%82%D0%B5%20%D1%81%D0%B2%D0%BE%D1%94%20%D0%B0%D0%B2%D1%82%D0%BE%20%D0%B4%D0%BE%20%D0%B7%D0%B8%D0%BC%D0%B8%20%D1%80%D0%B0%D0%B7%D0%BE%D0%BC%20%D0%B7%20%D0%BD%D0%B0%D0%BC%D0%B8%20(2).jpg"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_for_brands),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: "Популярні категорії"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_category_in_main_category_in_main__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: "Інші категорії"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link_cont),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        href: "/categories/olyva-zmazka--i-tehnichni",
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .droplet */ .ZO,
                                            "Оливи та рідини"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/galmivna-systema",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .discbrake */ .FZ,
                                            "Гальмівна система"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/systema-zapalyuvannya-rozzharyuvannya",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .fireIgn */ .V_,
                                            "Запалення/розжарювання"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/obigriv-kondytsioner",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .hodovaa */ .eq,
                                            "Опалення/кондиціонування"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/rulova-systema",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .remni */ .Eo,
                                            "Рульова система"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/kuzov-skladovi",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .accecories */ .iD,
                                            "Кузовні елемнти"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/systema-vypusku-vpusku-povitrya",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .electric */ .tu,
                                            "Впуск/випуск"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/systemy-pidgotovky-podachi-palyva",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .tiress */ .Er,
                                            "Подача палива"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/categories/aksesuary-zasoby-po-doglyadu-dod.tovary",
                                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().category_link),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .kuzov */ .ER,
                                            "Аксесуари"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }) : null,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().why_we),
                        children: "Чому вигідно працювати з нами?"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_descr),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc1),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .sighn */ .vu,
                                    "Ми відповідаємо за правильний підбір запчастин"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc1),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .checkbox1 */ .T9,
                                    "Більше 5 тисяч запчастин до усіх марок"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc1),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .watch */ .YP,
                                    "Швидко відповідаємо (до 20 хвилин)"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().why_we),
                        children: "Відгуки наших покупців"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_descr),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc2),
                                children: [
                                    "Галина (власниця KIA Venga)",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://static.wixstatic.com/media/1dd549_6f21d4850b964cdf913e61c940b41186~mv2.jpg/v1/fill/w_647,h_367,al_c,lg_1,q_80,enc_auto/1dd549_6f21d4850b964cdf913e61c940b41186~mv2.jpg"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc2),
                                children: [
                                    "Пан Остап (власник KIA Sportage)",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://static.wixstatic.com/media/1dd549_c315377f510445efa023b1dcbecd4408~mv2.jpg/v1/fill/w_626,h_357,al_c,lg_1,q_80,enc_auto/1dd549_c315377f510445efa023b1dcbecd4408~mv2.jpg"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Newmainoage_module_css__WEBPACK_IMPORTED_MODULE_10___default().our_desc2),
                                children: [
                                    "Наталія (власниця Ford Escape)",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "https://static.wixstatic.com/media/1dd549_0a945f2d0ccd44a39e0decc02a8bb7ae~mv2.jpg/v1/fill/w_647,h_367,al_c,lg_1,q_80,enc_auto/1dd549_0a945f2d0ccd44a39e0decc02a8bb7ae~mv2.jpg"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const getServerSideProps = async ({ req  })=>{
    const userAgent = req.headers["user-agent"];
    return {
        props: {
            userAgent: userAgent
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewMainPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8132:
/***/ ((module) => {

"use strict";
module.exports = require("next-useragent");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3258:
/***/ ((module) => {

"use strict";
module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ 3291:
/***/ ((module) => {

"use strict";
module.exports = import("react-redux");;

/***/ }),

/***/ 2741:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._extends = _extends;
function _extends() {
    exports._ = exports._extends = _extends = Object.assign || function assign(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
        }

        return target;
    };

    return _extends.apply(this, arguments);
}


/***/ }),

/***/ 167:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,1664,4761,1639], () => (__webpack_exec__(6616)));
module.exports = __webpack_exports__;

})();