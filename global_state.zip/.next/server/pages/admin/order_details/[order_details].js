(() => {
var exports = {};
exports.id = 6379;
exports.ids = [6379,2197];
exports.modules = {

/***/ 9918:
/***/ ((module) => {

// Exports
module.exports = {
	"order_details_main": "Order_details_order_details_main__gvJNs",
	"delivery_box": "Order_details_delivery_box__QhHNu",
	"order_box": "Order_details_order_box__9xIuK",
	"status_title": "Order_details_status_title__GbyHL",
	"order_item": "Order_details_order_item__Jf1gA",
	"title": "Order_details_title__H8nzb",
	"title_delivery": "Order_details_title_delivery__RF0i5",
	"article": "Order_details_article__0y_1K",
	"link_to_list": "Order_details_link_to_list__slH7p",
	"page_container_toLogin": "Order_details_page_container_toLogin___BGT5",
	"goToLoginLink": "Order_details_goToLoginLink__ogcn9",
	"return_btn": "Order_details_return_btn__Qf0k1",
	"deivery_oprion": "Order_details_deivery_oprion__kHcjM"
};


/***/ }),

/***/ 7106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9918);
/* harmony import */ var _styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);



const OrderItem = (order)=>{
    console.log(order.amount);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().order_item),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: order.orderItem.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().article),
                children: order.orderItem.article
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    order.amount,
                    " шт"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    order.orderItem.price * order.amount,
                    " грн"
                ]
            })
        ]
    });
};
const OrderDetails = ({ productData  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().order_details_main),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().title),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/admin/order_list",
                        className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().link_to_list),
                        children: "До списку замовлень"
                    }),
                    "Деталі замовлення #",
                    productData.order_id,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().status_title),
                        children: productData.status
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().order_box),
                children: productData.order_items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrderItem, {
                        orderItem: item,
                        amount: productData.items_amount[item.article]
                    }))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().title_delivery),
                children: "Деталі доставки"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Order_details_module_css__WEBPACK_IMPORTED_MODULE_2___default().delivery_box),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            " ",
                            "Отримувач : ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                children: productData.delivery_info.pib
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            " Номер телефону : ",
                            productData.delivery_info.phone
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            " Місто : ",
                            productData.delivery_info.city
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            " Відділення : ",
                            productData.delivery_info.department
                        ]
                    })
                ]
            })
        ]
    });
};
const getServerSideProps = async ({ params  })=>{
    if (params.order_details == "") {
        return;
    }
    const orderNumber = params.order_details;
    const res = await fetch(`https://api.bonapart.pro/findOrder/${orderNumber}`, {
        method: "GET"
    });
    const body = await res.json();
    return {
        props: {
            productData: body
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderDetails);


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2741:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._extends = _extends;
function _extends() {
    exports._ = exports._extends = _extends = Object.assign || function assign(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
        }

        return target;
    };

    return _extends.apply(this, arguments);
}


/***/ }),

/***/ 167:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,1664], () => (__webpack_exec__(7106)));
module.exports = __webpack_exports__;

})();