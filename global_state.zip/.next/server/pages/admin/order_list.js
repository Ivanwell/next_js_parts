(() => {
var exports = {};
exports.id = 3242;
exports.ids = [3242];
exports.modules = {

/***/ 6774:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Order_list_main__wzpky",
	"greenwall": "Order_list_greenwall__eClxS",
	"order_list_container": "Order_list_order_list_container__BbXxd",
	"order_item": "Order_list_order_item__M3yCu",
	"order_item_new": "Order_list_order_item_new__fVyUt",
	"order_item_process": "Order_list_order_item_process__r0c9z",
	"order_item_compelte": "Order_list_order_item_compelte___0S_j",
	"order_item_reject": "Order_list_order_item_reject__ICBty",
	"select_status": "Order_list_select_status__tf1bH",
	"update_status_btn": "Order_list_update_status_btn__0Uoy8"
};


/***/ }),

/***/ 3795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6774);
/* harmony import */ var _styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
"use client";




const Order = ({ data  })=>{
    const [choosedStatus, setChoosedStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data.status);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const id = data._id;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const updateOrderStatus = async ()=>{
        setLoading(true);
        const date = new Date();
        const year = date.getFullYear();
        let month = date.getMonth() + 1;
        if (month < 10) {
            month = `0${month}`;
        }
        let day = date.getDate();
        if (day < 10) {
            day = `0${day}`;
        }
        const hour = date.getHours();
        let minutes = date.getMinutes();
        if (minutes < 10) {
            minutes = `0${minutes}`;
        }
        const finalDate = `${day}.${month}.${year}, ${hour}:${minutes}`;
        let token = await fetch(`https://api.bonapart.pro/updateOrderStatus/${id}`, {
            headers: {
                "Content-Type": "application/json"
            },
            method: "PATCH",
            body: JSON.stringify({
                statusOrder: choosedStatus,
                lastUpdateTime: finalDate
            })
        });
        setLoading(false);
    };
    const goToOrderDetails = ()=>{
        router.push(`/admin/order_details/${data.order_id}`);
    };
    const statuses = [
        "Замовлення в обробці",
        "Товар прямує до нас на склад",
        "У нас на складі",
        "В дорозі до покупця",
        "В поштовому відділенні",
        "Замовлення виконане",
        "Відмова постачальника",
        "Замовлення створене, та ще не обробилось нашою системою"
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_item),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: "Номер замовлення"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: choosedStatus === "Замовлення виконане" ? (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_item_compelte) : choosedStatus === "У нас на складі" || choosedStatus === "Замовлення в обробці" || choosedStatus === "В дорозі до покупця" || choosedStatus === "В поштовому відділенні" || choosedStatus === "Товар прямує до нас на склад" ? (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_item_process) : choosedStatus === "Відмова постачальника" ? (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_item_reject) : (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_item_new),
                onClick: ()=>goToOrderDetails(),
                children: data.order_id
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: "Статус"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().select_status),
                onChange: (e)=>setChoosedStatus(e.target.value),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: data.status,
                        choosed: true,
                        children: data.status
                    }),
                    statuses.map((status)=>{
                        if (status === data.status) {} else return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: status,
                            children: status
                        });
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().update_status_btn),
                onClick: ()=>updateOrderStatus(),
                children: loading ? "..." : "Оновити статус"
            })
        ]
    });
};
const OrderList = ({ orders  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
            className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().main),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().greenwall)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().order_list_container),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            children: "Замовлення клієнтів"
                        }),
                        orders.map((order)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Order, {
                                data: order
                            }))
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Order_list_module_css__WEBPACK_IMPORTED_MODULE_3___default().greenwall)
                })
            ]
        })
    });
};
const getServerSideProps = async ()=>{
    const res = await fetch(`https://api.bonapart.pro/getOrders`, {
        method: "GET"
    });
    const body = await res.json();
    return {
        props: {
            orders: body
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderList);


/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3795));
module.exports = __webpack_exports__;

})();