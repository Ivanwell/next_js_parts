"use strict";
(() => {
var exports = {};
exports.id = 4462;
exports.ids = [4462];
exports.modules = {

/***/ 9108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(591);
/* harmony import */ var _styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4761);
/* harmony import */ var _components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9093);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_lib_gtag__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5881);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8132);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_useragent__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5678);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3291);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_7__, react_redux__WEBPACK_IMPORTED_MODULE_8__]);
([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_7__, react_redux__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Item = ({ item , productDescription , userAgent  })=>{
    let ua;
    if (userAgent.uaString) {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_6__.useUserAgent)(userAgent.uaString);
    } else {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_6__.useUserAgent)(window.navigator.userAgent);
    }
    let array;
    let array1;
    let metateg;
    let metateg2;
    if (productDescription.details) {
        array = Object.values(productDescription?.details);
        array1 = Object.keys(productDescription?.details);
    }
    if (productDescription.fits.length > 0) {
        metateg = `Придбати за ${item.price} грн ${item.title} до ${productDescription.fits.map((brand)=>`${brand.models.map((model)=>`${brand.brand} ${model.model}`)}`)}.`;
        metateg2 = `✅Підходить до : ${productDescription.fits.map((brand)=>`${brand.models.map((model)=>`${brand.brand} ${model.model}`)}`)}`;
    } else {
        metateg = `✅Придбати за ${item.price} грн ${item.title}. Номери аналогів : ${productDescription.oe.slice(0, 10).map((number)=>`${number.number}`)}.`;
        metateg2 = metateg;
    }
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const [end, setEnd] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(10);
    const [numerPerItem, setNumberPerItem] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [numberPhone, setNumberPhone] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [vin, setVin] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [openedDetailsMobile, setOpenedDetailsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openedFitsMobile, setOpenedFitsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openOE, setOpenOE] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const title = `${item.brandName} ${item.article} ${item.title}`;
    function capitalize(s) {
        return s[0].toUpperCase() + s.slice(1);
    }
    const addingToCard = (item)=>{
        const newItem = {
            ...item,
            quantity: numerPerItem
        };
        dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_7__/* .adddToCart */ .O3)(newItem));
    };
    const addNumberPerItem = (number)=>{
        if (numerPerItem + number === 0) {
            return;
        } else setNumberPerItem((prev)=>prev + number);
    };
    const check_compatability = (e)=>{
        e.preventDefault();
        router.push(`/`);
        _components_lib_gtag__WEBPACK_IMPORTED_MODULE_9__/* .event */ .B({
            action: "generate_lead"
        });
        fetch(`https://api.telegram.org/bot6173056848:AAE0eviFsiQtx0CWxEJyBizEdl_zhaJ0P1w/sendMessage?chat_id=@edetalRequests&text=Запит на перевірку BayrakParts Stock! ${" Вінкод : " + vin + " Артикул : " + item.article + " Клієнт " + name + " " + numberPhone}`);
    };
    const goTopreviousPage = ()=>{
        router.back();
    };
    const linkToPage = `https://bayrakparts.com/stock/${item.article}`;
    const date = new Date();
    const year = date.getFullYear();
    let month = date.getMonth() + 1;
    if (month < 10) {
        month = `0${month}`;
    }
    let day = date.getDate();
    if (day < 10) {
        day = `0${day}`;
    }
    const finalDate = `${year}-${month}-${date}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_item),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title.slice(0, 55) + `... купити , ціна ${item.price} грн`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: metateg
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: title.slice(0, 55) + `... купити , ціна ${item.price} грн`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: metateg2
                    })
                ]
            }),
            !ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_item_desctop),
                typeof: "schema:Product",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:aggregateRating",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:AggregateRating",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:reviewCount",
                                    content: "4"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:ratingValue",
                                    content: "4.9",
                                    children: "4,4"
                                }),
                                " ",
                                "stars"
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:offers",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:Offer",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:price",
                                    content: item.price
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "https://schema.org/InStock"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceCurrency",
                                    content: "UAH"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceValidUntil",
                                    datatype: "xsd:date",
                                    content: finalDate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    rel: "schema:url",
                                    resource: linkToPage
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:itemCondition",
                                    content: "https://schema.org/NewCondition"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_image),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().brand_title),
                                children: item.brandName
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                rel: "schema:image",
                                resource: item.img,
                                src: item.img,
                                alt: item.title,
                                loading: "lazy"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().informaton_container),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_item_title),
                                property: "schema:name",
                                content: item.title,
                                children: title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_item_atcile),
                                children: [
                                    "Артикул : ",
                                    item.article
                                ]
                            }),
                            productDescription.details ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_item_details),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Характеристики:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    array1.map((key, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().item_detail_row),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: capitalize(key)
                                                }),
                                                " : ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: array[index]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                            ]
                                        }))
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_item_details),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Характеристики:"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().item_detail_row),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: "Немає інформації"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().returning_cont),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .returning */ .jy,
                                    " 14 днів гарантованого повернення"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().purchaise_container),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().wishlist_and_stock),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .heart */ .sd,
                                            " Додати до відстеження"
                                        ]
                                    }),
                                    item.lvivStock === 0 && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .preorder */ .ef,
                                            " Під замовлення"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .box */ .BZ,
                                            " В наявності"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().price_container_with_disc),
                                children: [
                                    item.lvivStock === 1 || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price_and_disc_cont),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price),
                                                children: [
                                                    Math.ceil(item.price * 1.25),
                                                    " UAH"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().disc_container),
                                                children: "-20%"
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().real_price),
                                        children: [
                                            item.price,
                                            ",00 UAH"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().deliver_cost),
                                        children: " + Вартість доставки"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().aviability_cont),
                                children: item.lvivStock === 1 || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().last_item_cont),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "https://bayrakparts.com/media/hot-icon.svg",
                                            alt: "fire",
                                            loading: "lazy"
                                        }),
                                        "Остання шт на складі"
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().how_many_available),
                                    children: [
                                        +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                                        " шт доступно"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_items_container),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btn),
                                        onClick: ()=>addNumberPerItem(-1),
                                        children: "-"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().added_items),
                                        children: numerPerItem
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btn),
                                        onClick: ()=>addNumberPerItem(1),
                                        children: "+"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().buy_btn),
                                onClick: ()=>addingToCard(item),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .newbasket */ .Aj,
                                    "Купити"
                                ]
                            })
                        ]
                    })
                ]
            }) : null,
            !ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_item_desctop),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_and_compability),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_title),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .oeNumbers */ .hY,
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: "Оригінальні номери"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_numbers),
                                children: [
                                    productDescription.oe.slice(0, end).map((brand)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().number_and_brand),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.brand?.toUpperCase()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.number?.toUpperCase()
                                                })
                                            ]
                                        })),
                                    productDescription.oe.length < 10 ? null : end >= productDescription.oe.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().more_button),
                                        onClick: ()=>setEnd(10),
                                        children: "Згорнути"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().more_button),
                                        onClick: ()=>setEnd((prev)=>prev + 10),
                                        children: "Ще..."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_and_compability),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_title),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .car */ .ZB,
                                    "Підходить до таких авто"
                                ]
                            }),
                            productDescription.fits.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().non_info),
                                children: "Немає інформації"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                fits: productDescription.fits
                            })
                        ]
                    })
                ]
            }) : null,
            !ua.isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_item_desctop),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_for_question),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_oem_title),
                            children: [
                                _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .help */ .R_,
                                "Безкоштовно перевіримо чи підійде ",
                                item.brandName,
                                " ",
                                item.article,
                                " до Вашого авто"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().request_form_cont),
                            onSubmit: (e)=>check_compatability(e),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().description_request),
                                    children: [
                                        "1. Для перевірки потрібно лише вінкод та Ваші контактні дані",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().description_question),
                                            children: "Якщо у Вас є запитання про продукт або потребуєте більш детальної інформації, залиште свої побажання у полі нижче та ми з радістю надамо усю необхідну інформацію."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().row_for_name_numberphone),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_name_phone),
                                            placeholder: "Ім'я *",
                                            required: true,
                                            minLength: 4,
                                            onChange: (e)=>setName(e.target.value)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_name_phone),
                                            placeholder: "Телефон *",
                                            required: true,
                                            minLength: 10,
                                            onChange: (e)=>setNumberPhone(e.target.value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().description_request),
                                    children: "2. Вінкод знаходиться у свідоцтві про реєстрацію або у додатку 'ДІЯ'"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_vin),
                                    placeholder: "VIN *",
                                    required: true,
                                    minLength: 17,
                                    onChange: (e)=>setVin(e.target.value)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_question),
                                    type: "text",
                                    placeholder: "Ваше запитання до наших спеціалістів"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().submit_button),
                                    type: "submit",
                                    children: "Надіслати запит"
                                })
                            ]
                        })
                    ]
                })
            }) : null,
            ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_item_mobile),
                typeof: "schema:Product",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:aggregateRating",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:AggregateRating",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:reviewCount",
                                    content: "4"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:ratingValue",
                                    content: "4.9",
                                    children: "4,9"
                                }),
                                "stars"
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:offers",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:Offer",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:price",
                                    content: item.price
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "https://schema.org/InStock"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceCurrency",
                                    content: "UAH"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceValidUntil",
                                    datatype: "xsd:date",
                                    content: finalDate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    rel: "schema:url",
                                    resource: linkToPage
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:itemCondition",
                                    content: "https://schema.org/NewCondition"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().go_back_cont),
                        onClick: ()=>goTopreviousPage(),
                        children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .arrowLeft */ .e2
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().top_info_mobile),
                        property: "schema:name",
                        content: item.title,
                        children: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().article_mobile),
                        children: [
                            "Артикул : ",
                            item.article
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().image_mobile),
                        src: item.img,
                        alt: item.title,
                        rel: "schema:image",
                        resource: item.img,
                        loading: "lazy"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().price_info_cont),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().stock_info_cont),
                                children: [
                                    item.lvivStock === 1 || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().last_item_cont),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "https://bayrakparts.com/media/hot-icon.svg",
                                                alt: "fire",
                                                loading: "lazy"
                                            }),
                                            "Остання шт на складі"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().how_many_available),
                                        children: [
                                            +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                                            " шт доступно"
                                        ]
                                    }),
                                    item.lvivStock === 0 && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().out_stock_info),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .preorder */ .ef,
                                            " Під замовлення"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().in_stock_info),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .box2 */ .O1,
                                            " В наявності"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().price_container_with_disc),
                                children: [
                                    item.lvivStock === 1 || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price_and_disc_cont),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price),
                                                children: [
                                                    Math.ceil(item.price * 1.25),
                                                    " UAH"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().disc_container),
                                                children: "-20%"
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().real_price),
                                        children: [
                                            item.price,
                                            ",00 UAH"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().deliver_cost),
                                        children: " + Вартість доставки"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().buttons_container),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btns_container),
                                children: [
                                    numerPerItem,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btns),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .arrowup */ .Bz
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(-1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .arrowDown */ .DI
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().buy_button_mobile),
                                onClick: ()=>addingToCard(item),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .newbasket */ .Aj,
                                    "Купити"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().return_container),
                        children: [
                            "14 днів гарантованого повернення",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().returning_mobile),
                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .returning */ .jy
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detal_title_mobile),
                                onClick: ()=>setOpenedDetailsMobile((prev)=>!prev),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .gear */ .zf,
                                            "Деталі"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().center),
                                        children: !openedDetailsMobile ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openedDetailsMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().info_container),
                                children: productDescription.details ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: array1.map((key, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().item_detail_row),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_key),
                                                    children: [
                                                        capitalize(key),
                                                        ":"
                                                    ]
                                                }),
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_value),
                                                    children: array[index]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                            ]
                                        }))
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().item_detail_row),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: "Немає інформації"
                                    })
                                })
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detal_title_mobile),
                                onClick: ()=>setOpenedFitsMobile((prev)=>!prev),
                                children: [
                                    " ",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .car */ .ZB,
                                            "Підходить до таких авто"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().center),
                                        children: !openedFitsMobile ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openedFitsMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().info_container),
                                children: productDescription.fits.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().non_info),
                                    children: "Немає інформації"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fits: productDescription.fits
                                })
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detal_title_mobile),
                                onClick: ()=>setOpenOE((prev)=>!prev),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .oeNumbers */ .hY,
                                            "Оригінальні номери"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().center),
                                        children: !openOE ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openOE ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().info_container),
                                children: [
                                    productDescription.oe.slice(0, end).map((brand)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().number_and_brand),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.brand.toUpperCase()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.number.toUpperCase()
                                                })
                                            ]
                                        })),
                                    productDescription.oe.length < 10 ? null : end >= productDescription.oe.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().more_button),
                                        onClick: ()=>setEnd(10),
                                        children: "Згорнути"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().more_button),
                                        onClick: ()=>setEnd((prev)=>prev + 10),
                                        children: "Ще..."
                                    })
                                ]
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().detal_title_mobile),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().icon_and_name),
                                    children: [
                                        _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .help */ .R_,
                                        "Безкоштовно перевіримо"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().request_form_cont),
                                onSubmit: (e)=>check_compatability(e),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Залиште вінкод Вашого авто, та ми безкоштовно перевіримо чи підійде дана запчастина до нього"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_name_phone),
                                        placeholder: "Ім'я *",
                                        required: true,
                                        minLength: 4,
                                        onChange: (e)=>setName(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_name_phone),
                                        placeholder: "Телефон *",
                                        required: true,
                                        minLength: 10,
                                        onChange: (e)=>setNumberPhone(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().input_vin_mobile),
                                        placeholder: "VIN *",
                                        required: true,
                                        minLength: 17,
                                        onChange: (e)=>setVin(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_10___default().submit_button_mobile),
                                        type: "submit",
                                        children: "Надіслати запит"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }) : null
        ]
    });
};
const getServerSideProps = async ({ req , params  })=>{
    const article = params.stock;
    const res = await fetch(`https://api.bonapart.pro/findProduct/${article}`, {
        method: "GET"
    });
    const body = await res.json();
    if (!body) {
        return null;
    }
    const item = {
        title: body.name,
        price: Math.ceil(body.price * 1.15),
        img: body.image,
        article: body.article,
        brandName: body.brand,
        lvivStock: body.amount,
        otherStock: "-"
    };
    let fit = body.fit;
    if (!fit) {
        fit = [];
    }
    const productDescription = {
        fits: fit,
        details: null,
        oe: [
            {
                brand: item.brandName,
                number: item.article
            }
        ]
    };
    const userAgent = req.headers["user-agent"];
    return {
        props: {
            item,
            productDescription,
            userAgent
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Item);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8132:
/***/ ((module) => {

module.exports = require("next-useragent");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3258:
/***/ ((module) => {

module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ 3291:
/***/ ((module) => {

module.exports = import("react-redux");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4761,5678,9588], () => (__webpack_exec__(9108)));
module.exports = __webpack_exports__;

})();