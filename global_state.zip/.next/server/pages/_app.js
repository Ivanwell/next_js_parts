(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,2197];
exports.modules = {

/***/ 8946:
/***/ ((module) => {

// Exports
module.exports = {
	"red_back": "Preloader_red_back__VI0qf",
	"text": "Preloader_text___6tvT"
};


/***/ }),

/***/ 5881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ event),
/* harmony export */   "LV": () => (/* binding */ pageview)
/* harmony export */ });
/* unused harmony export GA_TRACKING_ID */
const GA_TRACKING_ID = "G-6SSFMSDB43";
const pageview = (url)=>{
    window.gtag("config", GA_TRACKING_ID, {
        page_path: url
    });
};
const event = ({ action , params  })=>{
    window.gtag("event", action, params);
};


/***/ }),

/***/ 7042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/Preloader.module.css
var Preloader_module = __webpack_require__(8946);
var Preloader_module_default = /*#__PURE__*/__webpack_require__.n(Preloader_module);
;// CONCATENATED MODULE: ./components/preloader.js


const Preloader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("h1", {
        className: (Preloader_module_default()).red_back,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Preloader_module_default()).text,
            children: "BayrakParts"
        })
    });
};
/* harmony default export */ const preloader = (Preloader);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/lib/gtag.js
var gtag = __webpack_require__(5881);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./pages/_app.js








function App({ Component , pageProps: { session , ...pageProps }  }) {
    const router = (0,router_.useRouter)();
    const [loading, setLoading] = (0,external_react_.useState)(false);
    const DynamicHeader = dynamic_default()(()=>Promise.all(/* import() */[__webpack_require__.e(730), __webpack_require__.e(1664), __webpack_require__.e(4761), __webpack_require__.e(5678), __webpack_require__.e(1639), __webpack_require__.e(9752)]).then(__webpack_require__.bind(__webpack_require__, 9752)), {
        loadableGenerated: {
            modules: [
                "_app.js -> " + "@/components/layout/layout"
            ]
        },
        loading: ()=>/*#__PURE__*/ jsx_runtime_.jsx(preloader, {})
    });
    const handleStart = (url)=>{
        setLoading(true);
    };
    const handleComplete = (url)=>{
        setLoading(false);
    };
    (0,external_react_.useEffect)(()=>{
        router.events.on("routeChangeStart", handleStart);
        router.events.on("routeChangeComplete", handleComplete);
        router.events.on("routeChangeError", handleComplete);
        return ()=>{
            router.events.off("routerChangeStart", handleStart);
            router.events.off("routerChangeComplete", handleComplete);
            router.events.off("routerChangeError", handleComplete);
        };
    }, []);
    (0,external_react_.useEffect)(()=>{
        const handleRouteChange = (url)=>{
            gtag/* pageview */.LV(url);
        };
        router.events.on("routeChangeComplete", handleRouteChange);
        return ()=>{
            router.events.off("routeChangeComplete", handleRouteChange);
        };
    }, [
        router.events
    ]);
    const [showChild, setShowChild] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        setShowChild(true);
    }, []);
    if (!showChild) {
        return null;
    }
    if (true) {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    } else {}
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3258:
/***/ ((module) => {

"use strict";
module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ 3291:
/***/ ((module) => {

"use strict";
module.exports = import("react-redux");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5152], () => (__webpack_exec__(7042)));
module.exports = __webpack_exports__;

})();