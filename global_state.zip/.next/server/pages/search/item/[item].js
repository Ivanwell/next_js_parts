"use strict";
(() => {
var exports = {};
exports.id = 9231;
exports.ids = [9231,2197];
exports.modules = {

/***/ 2185:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(591);
/* harmony import */ var _styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9093);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4761);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_lib_gtag__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5881);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8132);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_useragent__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5678);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3291);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_8__, react_redux__WEBPACK_IMPORTED_MODULE_9__]);
([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_8__, react_redux__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Item = ({ item , userAgent , rating , reviews  })=>{
    let ua;
    if (userAgent.uaString) {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_7__.useUserAgent)(userAgent.uaString);
    } else {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_7__.useUserAgent)(window.navigator.userAgent);
    }
    let img;
    if (ua.isMobile) {
        img = item.img.slice(0, 28) + "320x320" + item.img.slice(28);
    } else {
        img = item.img.slice(0, 28) + "1920x1920" + item.img.slice(28);
    }
    const googleImage = item.img.slice(0, 28) + "320x320" + item.img.slice(28);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const [end, setEnd] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(10);
    const [numerPerItem, setNumberPerItem] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [numberPhone, setNumberPhone] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [vin, setVin] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [openedDetailsMobile, setOpenedDetailsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openedFitsMobile, setOpenedFitsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openOE, setOpenOE] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [loadingInformation, setLoadingInformation] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openedFormCheck, setOpenFormCheck] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [searchedCarByVin, setSearchedCarByVin] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const [checking, setChecking] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [minLength, setMinLength] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [productDescription, setProductDescription] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
        fits: [],
        details: null,
        oe: [
            {
                brand: item.brandName,
                number: item.article
            }
        ]
    });
    let metateg;
    let metateg2;
    if (productDescription.fits?.length > 0) {
        metateg = `✅Придбати за ${item.price} грн ${item.title} до ${productDescription.fits.map((brand)=>`${brand.models.map((model)=>`${brand.brand} ${model.model}`)}`)}.`;
        metateg2 = `✅Підходить до : ${productDescription.fits.map((brand)=>`${brand.models.map((model)=>`${brand.brand} ${model.model}`)}`)}`;
    } else {
        metateg = `✅Придбати за ${item.price} грн ${item.title}. Номери аналогів : ${productDescription.oe.slice(0, 10).map((number)=>`${number.number}`)}.`;
        metateg2 = metateg;
    }
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const abortController = new AbortController();
        const { signal  } = abortController;
        const data1 = {
            article1: item.uuid
        };
        const apiCall = async ()=>{
            try {
                setLoadingInformation(true);
                const res1 = await fetch(`https://api.bonapart.pro/bmpartinfopart?article1=${encodeURIComponent(data1.article1)}`, {
                    method: "GET"
                });
                const body1 = await res1.json();
                if (body1) {
                    setProductDescription((prev)=>{
                        return {
                            ...prev,
                            fits: body1.product?.cars,
                            details: body1.product?.details,
                            oe: body1.product?.oe
                        };
                    });
                }
                setLoadingInformation(false);
            } catch (error) {
                if (!signal?.aborted) {
                    console.error(error);
                    setLoadingInformation(false);
                }
            }
        };
        apiCall();
        return ()=>{
            abortController.abort();
        };
    }, []);
    const title = `${item.brandName} ${item.article.replace(/[&\/\\ ]/g, "")} ${item.title}`;
    const title1 = `⭐${item.brandName}⭐ ${item.article.replace(/[&\/\\ ]/g, "")} ${item.title}`;
    function capitalize(s) {
        return s[0].toUpperCase() + s.slice(1);
    }
    const addingToCard = (item)=>{
        const newItem = {
            ...item,
            quantity: numerPerItem
        };
        dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_8__/* .adddToCart */ .O3)(newItem));
    };
    const addNumberPerItem = (number)=>{
        if (numerPerItem + number === 0) {
            return;
        } else setNumberPerItem((prev)=>prev + number);
    };
    const check_compatability = (e)=>{
        e.preventDefault();
        router.push(`/thankyou`);
        _components_lib_gtag__WEBPACK_IMPORTED_MODULE_10__/* .event */ .B({
            action: "generate_lead"
        });
        fetch(`https://api.telegram.org/bot6173056848:AAE0eviFsiQtx0CWxEJyBizEdl_zhaJ0P1w/sendMessage?chat_id=@edetalRequests&text=Запит на перевірку BayrakParts BM! ${" Вінкод : " + vin + " Артикул : " + item.article + " Клієнт " + name + " " + numberPhone}`);
    };
    const goTopreviousPage = ()=>{
        router.back();
    };
    const check_vin = async (e)=>{
        e.preventDefault();
        setChecking(true);
        fetch(`https://api.telegram.org/bot6173056848:AAE0eviFsiQtx0CWxEJyBizEdl_zhaJ0P1w/sendMessage?chat_id=@edetalRequests&text=Перевірка BayrakParts BM! ${" Вінкод : " + vin + " Артикул : " + item.article}`);
        const res = await fetch(`https://api.bonapart.pro/get_info_by_vin?vin=${encodeURIComponent(vin)}`, {
            method: "GET"
        });
        const body = await res.json();
        setSearchedCarByVin(body);
        setChecking(false);
    };
    const check_vin_request = async (e)=>{
        e.preventDefault();
        if (numberPhone.length < 10) {
            setMinLength(true);
            return;
        }
        fetch(`https://api.telegram.org/bot6173056848:AAE0eviFsiQtx0CWxEJyBizEdl_zhaJ0P1w/sendMessage?chat_id=@edetalRequests&text=Запит на перевірку BayrakParts BM! ${" Вінкод : " + vin + " Артикул: " + item.article + ". Номер телефону " + numberPhone}`);
        _components_lib_gtag__WEBPACK_IMPORTED_MODULE_10__/* .event */ .B({
            action: "generate_lead"
        });
        router.push(`/thankyou`);
    };
    const linkToPage = `https://bayrakparts.com/search/item/${item.article}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().main_item),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title1.slice(0, 55) + `... купити , ціна ${item.price} грн`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: metateg
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "product"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: title.slice(0, 55) + `... купити , ціна ${item.price} грн`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: googleImage
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: metateg2
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: linkToPage
                    })
                ]
            }),
            !ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_item_desctop),
                typeof: "schema:Product",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:aggregateRating",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:AggregateRating",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:reviewCount",
                                    content: reviews.toString()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:ratingValue",
                                    content: rating
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:offers",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:Offer",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:price",
                                    content: item.price
                                }),
                                item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "http://schema.org/OutOfStock"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "https://schema.org/InStock"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceCurrency",
                                    content: "UAH"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceValidUntil",
                                    datatype: "xsd:date",
                                    content: "2029-12-31"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    rel: "schema:url",
                                    resource: linkToPage
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:itemCondition",
                                    content: "https://schema.org/NewCondition"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_image),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().brand_title),
                                children: item.brandName
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                rel: "schema:image",
                                resource: img,
                                src: img,
                                alt: item.title,
                                loading: "lazy"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().informaton_container),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().main_item_title),
                                property: "schema:name",
                                content: item.title,
                                children: title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().main_item_atcile),
                                children: [
                                    "Артикул : ",
                                    item.article
                                ]
                            }),
                            loadingInformation ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                children: "Завантаження..."
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: productDescription.details ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().main_item_details),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Характеристики:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        Object.keys(productDescription?.details).map((key, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().item_detail_row),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: capitalize(key)
                                                    }),
                                                    " :",
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: Object.values(productDescription?.details)[index]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                                ]
                                            }))
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().main_item_details),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Характеристики:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().item_detail_row),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: "Немає інформації"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().returning_cont),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .returning */ .jy,
                                    " 14 днів гарантованого повернення"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().purchaise_container),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().wishlist_and_stock),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .heart */ .sd,
                                            " Додати до відстеження"
                                        ]
                                    }),
                                    item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .preorder */ .ef,
                                            " Під замовлення"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().svg_and_title),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .box */ .BZ,
                                            " В наявності"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().price_container_with_disc),
                                children: [
                                    item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().old_price_and_disc_cont),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().old_price),
                                                children: [
                                                    Math.ceil(item.price * 1.25),
                                                    " UAH"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().disc_container),
                                                children: "-20%"
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().real_price),
                                        children: [
                                            item.price,
                                            ",00 UAH"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().deliver_cost),
                                        children: " + Вартість доставки"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().aviability_cont),
                                children: item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().last_item_cont),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "https://bayrakparts.com/media/hot-icon.svg",
                                            alt: "fire",
                                            loading: "lazy"
                                        }),
                                        "Остання шт на складі"
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().how_many_available),
                                    children: [
                                        +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                                        " шт доступно"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().add_remove_items_container),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().add_remove_btn),
                                        onClick: ()=>addNumberPerItem(-1),
                                        children: "-"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().added_items),
                                        children: numerPerItem
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().add_remove_btn),
                                        onClick: ()=>addNumberPerItem(1),
                                        children: "+"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().buy_btn),
                                onClick: ()=>addingToCard(item),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .newbasket */ .Aj,
                                    "Купити"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "#form",
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().buy_btn_check),
                                children: [
                                    "Чи підійде до мого авто ",
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .question */ .wv
                                ]
                            })
                        ]
                    })
                ]
            }) : null,
            !ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_item_desctop),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_and_compability),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_title),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .oeNumbers */ .hY,
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: "Оригінальні номери"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_numbers),
                                children: [
                                    productDescription.oe.slice(0, end).map((brand)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().number_and_brand),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.brand.toUpperCase()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.number.toUpperCase()
                                                })
                                            ]
                                        })),
                                    productDescription.oe.length < 10 ? null : end >= productDescription.oe.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().more_button),
                                        onClick: ()=>setEnd(10),
                                        children: "Згорнути"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().more_button),
                                        onClick: ()=>setEnd((prev)=>prev + 10),
                                        children: "Ще..."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_and_compability),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_title),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .car */ .ZB,
                                    "Підходить до таких авто"
                                ]
                            }),
                            productDescription.fits.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().non_info),
                                children: "Немає інформації"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                fits: productDescription.fits
                            })
                        ]
                    })
                ]
            }) : null,
            !ua.isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_item_desctop),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_for_question),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            name: "form",
                            href: "/"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().cont_for_oem_title),
                            children: [
                                _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .help */ .R_,
                                "Безкоштовно перевіримо чи підійде ",
                                item.brandName,
                                " ",
                                item.article.replace(/[&\/\\ ]/g, ""),
                                " до Вашого авто"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().request_form_cont),
                            onSubmit: (e)=>check_compatability(e),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().description_request),
                                    children: "1. Для перевірки потрібно лише вінкод та Ваші контактні дані"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().row_for_name_numberphone),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_name_phone),
                                            placeholder: "Ім'я *",
                                            required: true,
                                            minLength: 4,
                                            onChange: (e)=>setName(e.target.value)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_name_phone),
                                            placeholder: "Телефон *",
                                            required: true,
                                            minLength: 10,
                                            onChange: (e)=>setNumberPhone(e.target.value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().description_request),
                                    children: "2. Вінкод знаходиться у свідоцтві про реєстрацію або у додатку 'ДІЯ'"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_vin),
                                    placeholder: "VIN *",
                                    required: true,
                                    minLength: 17,
                                    onChange: (e)=>setVin(e.target.value)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().submit_button),
                                    type: "submit",
                                    children: "Надіслати запит"
                                })
                            ]
                        })
                    ]
                })
            }) : null,
            ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().container_item_mobile),
                typeof: "schema:Product",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:aggregateRating",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:AggregateRating",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:reviewCount",
                                    content: reviews.toString()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:ratingValue",
                                    content: rating
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        rel: "schema:offers",
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().nodisplay),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            typeof: "schema:Offer",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:price",
                                    content: item.price
                                }),
                                item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "http://schema.org/OutOfStock"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:availability",
                                    content: "https://schema.org/InStock"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceCurrency",
                                    content: "UAH"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:priceValidUntil",
                                    datatype: "xsd:date",
                                    content: "2029-12-31"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    rel: "schema:url",
                                    resource: linkToPage
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    property: "schema:itemCondition",
                                    content: "https://schema.org/NewCondition"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().go_back_cont),
                        onClick: ()=>goTopreviousPage(),
                        children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .arrowLeft */ .e2
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().top_info_mobile),
                        property: "schema:name",
                        content: item.title,
                        children: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().article_mobile),
                        children: [
                            "Артикул : ",
                            item.article
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().image_mobile),
                        src: img,
                        alt: item.title,
                        rel: "schema:image",
                        resource: img,
                        loading: "lazy"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().price_info_cont),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().stock_info_cont),
                                children: [
                                    item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().last_item_cont),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "https://bayrakparts.com/media/hot-icon.svg",
                                                alt: "fire",
                                                loading: "lazy"
                                            }),
                                            "Остання шт на складі"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().how_many_available),
                                        children: [
                                            +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                                            " шт доступно"
                                        ]
                                    }),
                                    item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().out_stock_info),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .preorder */ .ef,
                                            " Під замовлення"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().in_stock_info),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .box2 */ .O1,
                                            " В наявності"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().price_container_with_disc),
                                children: [
                                    item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().old_price_and_disc_cont),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().old_price),
                                                children: [
                                                    Math.ceil(item.price * 1.25),
                                                    " UAH"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().disc_container),
                                                children: "-20%"
                                            })
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().real_price),
                                        children: [
                                            item.price,
                                            ",00 UAH"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().deliver_cost),
                                        children: " + Вартість доставки"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().buttons_container),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().add_remove_btns_container),
                                children: [
                                    numerPerItem,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().add_remove_btns),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .arrowup */ .Bz
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(-1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .arrowDown */ .DI
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().buy_button_mobile),
                                onClick: ()=>addingToCard(item),
                                children: [
                                    _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .newbasket */ .Aj,
                                    "Купити"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().return_container),
                        children: [
                            "14 днів гарантованого повернення",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().returning_mobile),
                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .returning */ .jy
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: !openedFormCheck ? (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().check_button_mobile) : (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().check_button_mobile_opened),
                        onClick: ()=>setOpenFormCheck((prev)=>!prev),
                        children: [
                            "Чи підійде до мого авто",
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .question */ .wv
                        ]
                    }),
                    openedFormCheck ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_cont_mobile),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().request_form_cont),
                            onSubmit: (e)=>check_vin(e),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Введіть вінкод"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_vin_mobile),
                                    placeholder: "VIN *",
                                    required: true,
                                    minLength: 17,
                                    onChange: (e)=>setVin(e.target.value)
                                }),
                                !searchedCarByVin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().submit_button_mobile),
                                    type: "submit",
                                    children: !checking ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: "Перевірити"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().loader)
                                    })
                                }) : null,
                                searchedCarByVin ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().searched_car_mobile),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: "Ваше авто "
                                        }),
                                        searchedCarByVin === "no car" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: "не знайдено"
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                searchedCarByVin.brand,
                                                " ",
                                                searchedCarByVin.model
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().searched_check_needed),
                                            children: [
                                                _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .info_circule */ .PQ,
                                                "Потрібна перевірка спеціалістом"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: "Залиште номер телефону та ми перевіримо чи запчастина підійде до Вашого авто"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_name_phone),
                                            placeholder: "Телефон *",
                                            onChange: (e)=>setNumberPhone(e.target.value)
                                        }),
                                        minLength ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().empty_name_phone),
                                            children: "Неповний номер телефону"
                                        }) : null,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().submit_button_mobile),
                                            onClick: (e)=>check_vin_request(e),
                                            children: "Перевірте будь ласка"
                                        })
                                    ]
                                }) : null
                            ]
                        })
                    }) : null,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detal_title_mobile),
                                onClick: ()=>setOpenedDetailsMobile((prev)=>!prev),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .gear */ .zf,
                                            "Деталі"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().center),
                                        children: !openedDetailsMobile ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openedDetailsMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().info_container),
                                children: !loadingInformation ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: productDescription.details ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: Object.keys(productDescription?.details).map((key, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().item_detail_row),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_key),
                                                        children: [
                                                            capitalize(key),
                                                            ":"
                                                        ]
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_value),
                                                        children: Object.values(productDescription?.details)[index]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                                ]
                                            }))
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().item_detail_row),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: "Немає інформації"
                                        })
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: "Завантаження..."
                                })
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detal_title_mobile),
                                onClick: ()=>setOpenedFitsMobile((prev)=>!prev),
                                children: [
                                    " ",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .car */ .ZB,
                                            "Підходить до таких авто"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().center),
                                        children: !openedFitsMobile ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openedFitsMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().info_container),
                                children: productDescription.fits.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().non_info),
                                    children: "Немає інформації"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_compatability_compatabikity__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fits: productDescription.fits
                                })
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detal_title_mobile),
                                onClick: ()=>setOpenOE((prev)=>!prev),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().icon_and_name),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .oeNumbers */ .hY,
                                            "Оригінальні номери"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().center),
                                        children: !openOE ? _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .plusCircule */ .OS : _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .minus */ .h9
                                    })
                                ]
                            }),
                            openOE ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().info_container),
                                children: [
                                    productDescription.oe.slice(0, end).map((brand)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().number_and_brand),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.brand.toUpperCase()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: brand.number.toUpperCase()
                                                })
                                            ]
                                        })),
                                    productDescription.oe.length < 10 ? null : end >= productDescription.oe.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().more_button),
                                        onClick: ()=>setEnd(10),
                                        children: "Згорнути"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().more_button),
                                        onClick: ()=>setEnd((prev)=>prev + 10),
                                        children: "Ще..."
                                    })
                                ]
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detail_cont_mobile),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().detal_title_mobile_form),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().icon_and_name),
                                    children: [
                                        _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_5__/* .help */ .R_,
                                        "Безкоштовно перевіримо"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().request_form_cont),
                                onSubmit: (e)=>check_compatability(e),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Залиште вінкод Вашого авто, та ми безкоштовно перевіримо чи підійде дана запчастина до нього"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_name_phone),
                                        placeholder: "Ім'я *",
                                        required: true,
                                        minLength: 4,
                                        onChange: (e)=>setName(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_name_phone),
                                        placeholder: "Телефон *",
                                        required: true,
                                        minLength: 10,
                                        onChange: (e)=>setNumberPhone(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().input_vin_mobile),
                                        placeholder: "VIN *",
                                        required: true,
                                        minLength: 17,
                                        onChange: (e)=>setVin(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_NewItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().submit_button_mobile),
                                        type: "submit",
                                        children: "Надіслати запит"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }) : null
        ]
    });
};
const getServerSideProps = async ({ req , params , query  })=>{
    const userAgent = req.headers["user-agent"];
    const data = {
        article1: params.item.replace(/[- /]/g, ""),
        brand: query.brand
    };
    function randomNumber(min, max) {
        return Math.random() * (max - min) + min;
    }
    const rating = randomNumber(4, 5).toString().slice(0, 3);
    let reviews = Math.floor(Math.random() * 10) + 1;
    if (query.brand) {
        const res = await fetch(`http://api.bonapart.pro/bmpart?article1=${encodeURIComponent(data.article1)}&brand=${encodeURIComponent(data.brand)}`, {
            method: "GET"
        });
        const item = await res.json();
        return {
            props: {
                item,
                userAgent,
                rating,
                reviews
            }
        };
    } else {
        const res = await fetch(`http://api.bonapart.pro/bmpart?article1=${encodeURIComponent(data.article1)}`, {
            method: "GET"
        });
        const item = await res.json();
        return {
            props: {
                item,
                userAgent,
                rating,
                reviews
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Item);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8132:
/***/ ((module) => {

module.exports = require("next-useragent");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3258:
/***/ ((module) => {

module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ 3291:
/***/ ((module) => {

module.exports = import("react-redux");;

/***/ }),

/***/ 2741:
/***/ ((__unused_webpack_module, exports) => {



exports._ = exports._extends = _extends;
function _extends() {
    exports._ = exports._extends = _extends = Object.assign || function assign(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
        }

        return target;
    };

    return _extends.apply(this, arguments);
}


/***/ }),

/***/ 167:
/***/ ((__unused_webpack_module, exports) => {



exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,1664,4761,5678,9588], () => (__webpack_exec__(2185)));
module.exports = __webpack_exports__;

})();