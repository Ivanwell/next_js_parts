"use strict";
(() => {
var exports = {};
exports.id = 2787;
exports.ids = [2787,2197];
exports.modules = {

/***/ 3638:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4761);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2646);
/* harmony import */ var _styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5678);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8132);
/* harmony import */ var next_useragent__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_useragent__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3291);
/* harmony import */ var _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__, react_redux__WEBPACK_IMPORTED_MODULE_8__, _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__]);
([_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__, react_redux__WEBPACK_IMPORTED_MODULE_8__, _global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const NoSearchResult = ({ title  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().nosearch_container),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().no_search_result),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().img_container),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://www.bayrakparts.com/media/pngegg.png"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().no_res_description),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                "Упс... система не знайшла ",
                                title
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Проте Ви можете залишити заявку і ми пошукаємо запчастину вручну"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: "/leave_request",
                            children: "Залишити заявку"
                        })
                    ]
                })
            ]
        })
    });
};
const SearchedItem = ({ product  })=>{
    const [numberPerItem, setNumberPerItem] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    let img = "https://cdn.bm.parts/photos/320x320" + product.default_image.slice(5).replace(/[&\/\\]/g, "/");
    const item = {
        title: product.name,
        price: Math.ceil(product.price * 1.15),
        img: img,
        article: product.article,
        brandName: product.brand,
        lvivStock: product.in_stocks[0].quantity,
        otherStock: product.in_others.quantity
    };
    const adddingToCard = (item)=>{
        const newItem = {
            ...item,
            quantity: numberPerItem
        };
        dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__/* .adddToCart */ .O3)(newItem));
    };
    const link = `/search/item/${item.article.replace(/[&\/\\]/g, "")}?brand=${item.brandName}`;
    const addNumberPerItem = (number)=>{
        if (numberPerItem + number === 0) {
            return;
        } else setNumberPerItem((prev)=>prev + number);
    };
    const title = `${item.brandName} ${item.article.replace(/[&\/\\ ]/g, "")} ${item.title}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().searched_item),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().img_cont),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().brand_up_photo),
                        children: item.brandName
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: img
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_info_product),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().top_name_item),
                        href: link,
                        children: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().artilce),
                        children: [
                            "Артикул: ",
                            item.article
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().title_prod_info),
                        children: "Інформація про продукт:"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().prod_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Номер запчастини:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: item.article
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().prod_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Виробник:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: item.brandName
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().prod_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Наша ціна:"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    item.price,
                                    " UAH"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().prod_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Стан:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Новий"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().purchaise_info),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_to_wish_list),
                        children: [
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .heart */ .sd,
                            " Додати до відстеження"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().price_container),
                        children: [
                            item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price_and_disc_cont),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price),
                                        children: [
                                            Math.ceil(item.price * 1.25),
                                            " UAH"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().disc_container),
                                        children: "-20%"
                                    })
                                ]
                            }) : null,
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().real_price),
                                children: [
                                    item.price,
                                    ",00 UAH"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().deliver_cost),
                                children: " + Вартість доставки"
                            })
                        ]
                    }),
                    item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().aviability_cont_out),
                        children: [
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .preorder */ .ef,
                            " Під замовлення"
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().aviability_cont),
                        children: [
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .box2 */ .O1,
                            " В наявності"
                        ]
                    }),
                    item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().last_item_cont),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "https://bayrakparts.com/media/hot-icon.svg"
                            }),
                            "Остання шт на складі"
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().how_many_available),
                        children: [
                            +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                            " шт доступно"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_min_btn_cont),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>addNumberPerItem(-1),
                                children: "-"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: numberPerItem
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>addNumberPerItem(1),
                                children: "+"
                            })
                        ]
                    }),
                    item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().ckeck_aviability),
                        children: "Уточнити наявність"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().byu_btn_search),
                        onClick: ()=>adddingToCard(item),
                        children: [
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .newbasket */ .Aj,
                            "Купити"
                        ]
                    })
                ]
            })
        ]
    });
};
const SearchedItemMobile = ({ product  })=>{
    const [numberPerItem, setNumberPerItem] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const goToItem = (item_article)=>{
        router.push(`/search/item/${item_article}`);
    };
    let img = "https://cdn.bm.parts/photos/320x320" + product.default_image.slice(5).replace(/[&\/\\]/g, "/");
    const item = {
        title: product.name,
        price: Math.ceil(product.price * 1.15),
        img: img,
        article: product.article,
        brandName: product.brand,
        lvivStock: product.in_stocks[0].quantity,
        otherStock: product.in_others.quantity
    };
    const adddingToCard = (item)=>{
        const newItem = {
            ...item,
            quantity: numberPerItem
        };
        dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__/* .adddToCart */ .O3)(newItem));
    };
    const link = `/search/item/${item.article.replace(/[&\/\\]/g, "")}?brand=${item.brandName}`;
    const addNumberPerItem = (number)=>{
        if (numberPerItem + number === 0) {
            return;
        } else setNumberPerItem((prev)=>prev + number);
    };
    const title = `${item.brandName} ${item.article.replace(/[&\/\\ ]/g, "")} ${item.title}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().separate_item_cont),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().top_item),
                children: [
                    item.brandName,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_wishlist),
                        children: [
                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .heart */ .sd,
                            " відстежувати"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_container_info_mobile),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().cont_for_img_and_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_img_container),
                                onClick: ()=>goToItem(item.article),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: img
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().main_info),
                                href: link,
                                children: [
                                    title,
                                    " ",
                                    item.lvivStock === "-" && item.otherStock === "-" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().aviability_cont_out),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .preorder */ .ef,
                                            " Під замовлення"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().aviability_cont),
                                        children: [
                                            _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .box2 */ .O1,
                                            " В наявності"
                                        ]
                                    }),
                                    item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().last_item_cont),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "https://bayrakparts.com/media/hot-icon.svg"
                                            }),
                                            "Остання шт на складі"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().how_many_available),
                                        children: [
                                            +item.lvivStock > 0 ? item.lvivStock : item.otherStock,
                                            " шт доступно"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().price_container),
                                        children: [
                                            item.lvivStock === "1" || item.lvivStock === "-" && item.otherStock === "1" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price_and_disc_cont),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().old_price),
                                                        children: [
                                                            Math.ceil(item.price * 1.25),
                                                            " UAH"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().disc_container),
                                                        children: "-20%"
                                                    })
                                                ]
                                            }) : null,
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().real_price),
                                                children: [
                                                    item.price,
                                                    ",00 UAH"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().deliver_cost),
                                                children: " + Вартість доставки"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().buttons_cont),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().detail_button),
                                onClick: ()=>goToItem(item.article),
                                children: "Деталі"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btns_container),
                                children: [
                                    numberPerItem,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().add_remove_btns),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .arrowup */ .Bz
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>addNumberPerItem(-1),
                                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .arrowDown */ .DI
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().byu_btn_mobile),
                                onClick: ()=>adddingToCard(item),
                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .newbasket */ .Aj
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const NewSearch = ({ productData , userAgent  })=>{
    let ua;
    if (userAgent.uaString) {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_7__.useUserAgent)(userAgent.uaString);
    } else {
        ua = (0,next_useragent__WEBPACK_IMPORTED_MODULE_7__.useUserAgent)(window.navigator.userAgent);
    }
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const formNewData = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.dataForSelects);
    const choosenBrand = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.brand);
    const choosenModel = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.model);
    const choosenCategory = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.category);
    const choosenPart = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.part);
    const loadingFromData = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.dataSelectscartReducer.value.loading);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (!formNewData) {
            const abortController = new AbortController();
            const { signal  } = abortController;
            const apiCall = async ()=>{
                try {
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setLoadingData */ .dm)(true));
                    const res = await fetch(`https://api.bonapart.pro/getSearchCatParts`, {
                        method: "GET",
                        signal: signal
                    });
                    const body = await res.json();
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setDataForForm */ ._1)(body[0].partsData));
                    dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setLoadingData */ .dm)(false));
                } catch (error) {
                    if (!signal?.aborted) {
                        console.error(error);
                        dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setLoadingData */ .dm)(false));
                    }
                }
            };
            apiCall();
            return ()=>{
                abortController.abort();
            };
        } else {}
    }, []);
    const [errorForm, setErrorForm] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const title = router.query.article;
    const submitingSearch = (e)=>{
        e.preventDefault();
        if (!choosenBrand || !choosenModel || !choosenCategory || !choosenPart) {
            setErrorForm(true);
        } else {
            setErrorForm(false);
            const article = choosenPart + " " + choosenBrand + " " + choosenModel;
            router.push(`/search/${article}`);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().whole_search_container),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: title
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_container),
                children: [
                    !ua.isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_model_cont),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_form),
                            onSubmit: (e)=>submitingSearch(e),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().container_search_form),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_car_title),
                                            children: [
                                                _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .search */ .XP,
                                                "Виберіть Ваше авто для пошуку запчастин"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                    children: "1"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                    value: choosenBrand,
                                                    onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setBrand */ .HB)(e.target.value)),
                                                    children: [
                                                        !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Оберіть марку"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Завантаження..."
                                                        }),
                                                        formNewData ? formNewData.brands.map((brand)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                children: brand
                                                            })) : null
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                    children: "2"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                    value: choosenModel,
                                                    onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setModel */ .j1)(e.target.value)),
                                                    children: [
                                                        !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Оберіть модель"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Завантаження..."
                                                        }),
                                                        choosenBrand ? formNewData.models.find((product)=>product.brandName === choosenBrand).Models.map((model1)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: model1,
                                                                children: model1
                                                            })) : null
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                    children: "3"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                    value: choosenCategory,
                                                    onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setCategory */ .PR)(e.target.value)),
                                                    children: [
                                                        !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Оберіть категорію"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Завантаження..."
                                                        }),
                                                        choosenModel ? formNewData.categories.map((categori)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: categori,
                                                                children: categori
                                                            })) : null
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().select_container),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().number),
                                                    children: "4"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                    onChange: (e)=>dispatch((0,_global_state_features_cardata_redux__WEBPACK_IMPORTED_MODULE_9__/* .setPart */ .rx)(e.target.value)),
                                                    value: choosenPart,
                                                    children: [
                                                        !loadingFromData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Оберіть запчастину"
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: "Завантаження..."
                                                        }),
                                                        choosenCategory ? formNewData.exactParts.find((castogory)=>castogory.catigory === choosenCategory).Models.map((part)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: part,
                                                                children: part
                                                            })) : null
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "submit",
                                            className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_button),
                                            children: "Пошук"
                                        })
                                    ]
                                }),
                                errorForm ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().error_form),
                                    children: "Заповніть усі дані"
                                }) : null,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    href: "/leave_request",
                                    className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().cannot_find_part),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().cannot_find_part_title),
                                        children: "Не вдається знайти запчастину? Ми допоможемо!"
                                    })
                                })
                            ]
                        })
                    }) : null,
                    !ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_result_cont),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                children: title
                            }),
                            productData.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_results),
                                children: productData.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchedItem, {
                                        product: product
                                    }))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NoSearchResult, {
                                title: title
                            })
                        ]
                    }) : null,
                    ua.isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_result_cont_mobile),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().go_back_cont),
                                children: _components_SVGs_SVGs__WEBPACK_IMPORTED_MODULE_3__/* .arrowLeft */ .e2
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewSearch_module_css__WEBPACK_IMPORTED_MODULE_10___default().search_results_mobile),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        children: title
                                    }),
                                    productData.length > 0 ? productData.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchedItemMobile, {
                                            product: product
                                        })) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NoSearchResult, {
                                        title: title
                                    })
                                ]
                            })
                        ]
                    }) : null
                ]
            })
        ]
    });
};
const getServerSideProps = async ({ req , params  })=>{
    const data = {
        article1: params.article
    };
    const userAgent = req.headers["user-agent"];
    const res = await fetch(`http://api.bonapart.pro/bmparts?article1=${encodeURIComponent(data.article1)}`, {
        method: "GET"
    });
    const body = await res.json();
    const array = Object.values(body.products);
    return {
        props: {
            productData: array,
            userAgent
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewSearch);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8132:
/***/ ((module) => {

module.exports = require("next-useragent");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3258:
/***/ ((module) => {

module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ 3291:
/***/ ((module) => {

module.exports = import("react-redux");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,1664,4761,5678,1639,2777], () => (__webpack_exec__(3638)));
module.exports = __webpack_exports__;

})();