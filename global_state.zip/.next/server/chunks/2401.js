exports.id = 2401;
exports.ids = [2401];
exports.modules = {

/***/ 7711:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Error_main__5EBxq",
	"container_full": "Error_container_full__S8MD0",
	"error_container": "Error_error_container__AEy35",
	"error_500_container": "Error_error_500_container__u_4KB",
	"cont_for_descr_and_link": "Error_cont_for_descr_and_link__nXo6c"
};


/***/ }),

/***/ 2741:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._extends = _extends;
function _extends() {
    exports._ = exports._extends = _extends = Object.assign || function assign(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
        }

        return target;
    };

    return _extends.apply(this, arguments);
}


/***/ }),

/***/ 167:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}


/***/ })

};
;