exports.id = 7159;
exports.ids = [7159];
exports.modules = {

/***/ 7961:
/***/ ((module) => {

// Exports
module.exports = {
	"full_container": "Links_full_container__dm8nw",
	"links": "Links_links__rH100",
	"pod_cat_cont": "Links_pod_cat_cont__IZgnq",
	"link_pod_category": "Links_link_pod_category__8BtOi"
};


/***/ }),

/***/ 7159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Links_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7961);
/* harmony import */ var _styles_Links_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Links_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4761);




const LinkHistory = ({ data  })=>{
    const link = `/categories/${data.eng}`;
    function capitalize(s) {
        return s[0].toUpperCase() + s.slice(1).toLowerCase();
    }
    const text = capitalize(data.ukr);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: link,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
            children: [
                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .arrowRight1 */ .ZU,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: text
                })
            ]
        })
    });
};
const LinksHistory = ({ fullPath  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            div: true,
            className: (_styles_Links_module_css__WEBPACK_IMPORTED_MODULE_3___default().links),
            children: fullPath.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkHistory, {
                    data: category
                }))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LinksHistory);


/***/ })

};
;