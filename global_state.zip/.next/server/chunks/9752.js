exports.id = 9752;
exports.ids = [9752];
exports.modules = {

/***/ 1003:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__Tl1eP",
	"whole_footer": "Footer_whole_footer__Jpe42",
	"footer_for_mobile": "Footer_footer_for_mobile__0uE4A",
	"whole_footer_container": "Footer_whole_footer_container__NVQJj",
	"column_links": "Footer_column_links__l9NiN",
	"column_link": "Footer_column_link__u198Y",
	"column_name": "Footer_column_name__LT3FX",
	"footer_row": "Footer_footer_row___6nGK"
};


/***/ }),

/***/ 5042:
/***/ ((module) => {

// Exports
module.exports = {
	"main_root": "Layuot_main_root__vIyhQ"
};


/***/ }),

/***/ 4643:
/***/ ((module) => {

// Exports
module.exports = {
	"whole_header": "NewNavbar_whole_header__rKFW2",
	"whole_image_cont": "NewNavbar_whole_image_cont__8dPM1",
	"mobile_menu_container": "NewNavbar_mobile_menu_container__uHyXy",
	"header_links": "NewNavbar_header_links__McD9P",
	"link_big": "NewNavbar_link_big__u48I_",
	"discount_box": "NewNavbar_discount_box__woYIk",
	"main_header": "NewNavbar_main_header___C_Cf",
	"header_top_desctop": "NewNavbar_header_top_desctop__MojCZ",
	"header_top_mobile": "NewNavbar_header_top_mobile__52UWQ",
	"header_logo": "NewNavbar_header_logo__N_qxp",
	"login": "NewNavbar_login__ziqkv",
	"number_in_circule_container": "NewNavbar_number_in_circule_container__GfCaA",
	"header_main": "NewNavbar_header_main__Qp_j9",
	"select_part": "NewNavbar_select_part__2LWYU",
	"search_container": "NewNavbar_search_container__FFg6e",
	"search_input": "NewNavbar_search_input__e4l0e",
	"basket_container": "NewNavbar_basket_container__7eq2R",
	"basket_and_numbers": "NewNavbar_basket_and_numbers__XnYCQ",
	"near_basket_items": "NewNavbar_near_basket_items__7fSjT",
	"small_font": "NewNavbar_small_font__uVJei",
	"total_sum": "NewNavbar_total_sum__Mufo7",
	"header_bottom": "NewNavbar_header_bottom__juoEO",
	"list_categories": "NewNavbar_list_categories__fV06_",
	"category": "NewNavbar_category__Ano_1",
	"added_to_cart_cont": "NewNavbar_added_to_cart_cont__lm87l",
	"menu-apearence": "NewNavbar_menu-apearence__IJpQF",
	"choose_to_proceed_or_back": "NewNavbar_choose_to_proceed_or_back__OLOej",
	"btn_checkout_btn": "NewNavbar_btn_checkout_btn__I9mB3",
	"btn_back_btn": "NewNavbar_btn_back_btn__JYhfm",
	"dots_bars_4": "NewNavbar_dots_bars_4__p5jMn",
	"db4-0": "NewNavbar_db4-0__8wCJH",
	"db4-1": "NewNavbar_db4-1___Vax8",
	"db4-2": "NewNavbar_db4-2__ywCeM",
	"no_result": "NewNavbar_no_result__Kms0E",
	"header_top": "NewNavbar_header_top__rppQN",
	"header_top_mobile_back": "NewNavbar_header_top_mobile_back__HVij2",
	"menu_burger_svg": "NewNavbar_menu_burger_svg__oD4hh",
	"search_container_mobile": "NewNavbar_search_container_mobile__9XPmn",
	"search_input_mobile": "NewNavbar_search_input_mobile__jyIh8",
	"search_mobele_btn": "NewNavbar_search_mobele_btn__0WWaT",
	"mobile_menu_links_container": "NewNavbar_mobile_menu_links_container__9OrEk",
	"title_in_mobile_menu": "NewNavbar_title_in_mobile_menu__v07vT",
	"links_menu_mobile": "NewNavbar_links_menu_mobile__XzzRP",
	"items_in_circule": "NewNavbar_items_in_circule__84UPG",
	"busket_mobile_cont": "NewNavbar_busket_mobile_cont__pvF5h"
};


/***/ }),

/***/ 9752:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _newnavbar_newnavbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9299);
/* harmony import */ var _newfooter_newfooter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7794);
/* harmony import */ var _styles_Layuot_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5042);
/* harmony import */ var _styles_Layuot_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Layuot_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _global_state_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2581);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_newnavbar_newnavbar__WEBPACK_IMPORTED_MODULE_1__, _global_state_provider__WEBPACK_IMPORTED_MODULE_3__]);
([_newnavbar_newnavbar__WEBPACK_IMPORTED_MODULE_1__, _global_state_provider__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Layout = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_global_state_provider__WEBPACK_IMPORTED_MODULE_3__/* .ReduxProvider */ .m, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_newnavbar_newnavbar__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    className: (_styles_Layuot_module_css__WEBPACK_IMPORTED_MODULE_4___default().main_root),
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_newfooter_newfooter__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1003);
/* harmony import */ var _styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4761);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);




const NewFooter = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().whole_footer),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().whole_footer_container),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_links),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_name),
                                children: "Про компанію"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/aboutus",
                                    children: "Коротко про нашу компанію"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/newcontacts",
                                    children: "Як з нами зв'язатись?"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/leave_request",
                                    children: "Залишити заявку"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_links),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_name),
                                children: "Підтримка клієнтів"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/payment_and_delivery",
                                    children: "Доставка"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/payment_and_delivery",
                                    children: "Оплата"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/return_policy",
                                    children: "Повернення"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/reklamatsia",
                                    children: "Рекламація"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/how_to_order",
                                    children: "Як підібрати запчастину?"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_links),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_name),
                                children: "Популярні товари"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Оливи 0W20"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Оливи 5W30"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Оливи 10W40"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Антифриз червоний"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Автолампа 12V"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_links),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_name),
                                children: "Швидкий зв'язок з нами"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Моб. тел. 093-728-93-84"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "E-mail : office@bayrakparts.com"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "Месенджери : Viber, Telegram, WhatsApp"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().column_link),
                                children: "ПН-СБ 9:00 - 19:00"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_for_mobile),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_row),
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .scedj */ .l8,
                            "ПН-ПТ 9:00 - 18:30"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: "tel:+380937289485",
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_row),
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .tel */ .Hd,
                            " +38 (093)-728-94-85"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_row),
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_1__/* .mail */ .X5,
                            "office@bayrakparts.com"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "\xa9 2023 Всі права захищено"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewFooter);


/***/ }),

/***/ 9299:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4643);
/* harmony import */ var _styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4761);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3291);
/* harmony import */ var _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5678);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_redux__WEBPACK_IMPORTED_MODULE_5__, _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__]);
([react_redux__WEBPACK_IMPORTED_MODULE_5__, _global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const NewNavbar = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const sumury = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cartReducer.value.total);
    const sumury2 = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cartReducer.value.sum);
    const openedProposal = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cartReducer.value.openedCheckoutProposal);
    const isImageShown = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cartReducer.value.imgCont.visibility);
    const fullImage = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cartReducer.value.imgCont.image);
    const [openedSearch, setOpenedSearch] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [openedMenuMobile, setOpenedMobileMenu] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [article, setArticle] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [noResults, setNoResults] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const searchInStock = async (e)=>{
        e.preventDefault();
        setLoading(true);
        const res = await fetch(`http://backend.bayrakparts.com/get_item_info/${article.replace(/[- /]/g, "").toUpperCase()}`, {
            method: "GET"
        });
        const body = await res.json();
        if (body) {
            router.push(`/product/${body.link[0].link}`);
        } else {
            setNoResults(true);
        }
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().whole_header),
        children: [
            isImageShown ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                onClick: ()=>dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__/* .hideFullImage */ .nu)()),
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().whole_image_cont),
                children: [
                    " ",
                    _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .closeSvg */ .K$,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: fullImage
                    })
                ]
            }) : null,
            openedProposal ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().added_to_cart_cont),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().choose_to_proceed_or_back),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: "Товар успішно доданий до кошика"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/checkout",
                            onClick: ()=>dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__/* .handleOpenPropToCheck */ .Zd)(false)),
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn_checkout_btn),
                            children: "Оформити замовлення"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn_back_btn),
                            onClick: ()=>dispatch((0,_global_state_features_cart_redux__WEBPACK_IMPORTED_MODULE_6__/* .handleOpenPropToCheck */ .Zd)(false)),
                            children: "Повернутись назад"
                        })
                    ]
                })
            }) : null,
            openedMenuMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().mobile_menu_container),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().mobile_menu_links_container),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().title_in_mobile_menu),
                            children: "BAYRAKPARTS"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .car */ .ZB,
                                        "Головна"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/how_to_order",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .search */ .XP,
                                        "Пошук"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/leave_request",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/leave_request",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .chat */ .W6,
                                        "Залишити заявку"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/aboutus",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/aboutus",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .infor */ .mz,
                                        "Про нас"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/checkout",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/checkout",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .smallBuscet */ .a8,
                                        "Корзина"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/track_order",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/track_order",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .garage1 */ .vy,
                                        "Відстежити"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/contacts",
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/contacts",
                                    children: [
                                        _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .tel */ .Hd,
                                        "Контакти"
                                    ]
                                }),
                                _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .onearrowright */ .Y
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().links_menu_mobile),
                            onClick: ()=>setOpenedMobileMenu(false),
                            children: _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .arrowLeft */ .e2
                        })
                    ]
                })
            }) : null,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_links),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().link_big),
                        href: "/",
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .info */ .um,
                            "ГОЛОВНА"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().link_big),
                        href: "/payment_and_delivery",
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .info */ .um,
                            "ДОСТАВКА ТА ОПЛАТА"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().link_big),
                        href: "/contacts",
                        children: [
                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .info */ .um,
                            "КОНТАКТИ"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().discount_box),
                children: "ВСТИГНІТЬ ОТРИМАТИ ЗИМОВУ ЗНИЖКУ 20%"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().main_header),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_top_desctop),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_logo),
                                children: "BAYRAKPARTS"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().login),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/track_order",
                                        title: "Відстежити замовлення",
                                        children: _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .garage1 */ .vy
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/payment_and_delivery",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .heart */ .sd,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().number_in_circule_container),
                                                children: "0"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .personWithoutAuth */ .xw,
                                            "Увійти"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    !openedSearch ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_top_mobile),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().menu_burger_svg),
                                onClick: ()=>setOpenedMobileMenu(true),
                                children: _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .menuBurger */ .ph
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_logo),
                                children: "BAYRAKPARTS"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().menu_burger_svg),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().menu_burger_svg),
                                        onClick: ()=>setOpenedSearch(true),
                                        children: _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .search */ .XP
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/checkout",
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().busket_mobile_cont),
                                        children: [
                                            sumury > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().items_in_circule),
                                                children: sumury
                                            }) : null,
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .smallBuscet */ .a8
                                        ]
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_top_mobile),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setOpenedSearch(false),
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_top_mobile_back),
                                children: _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .arrowLeft */ .e2
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().search_container_mobile),
                                onSubmit: (e)=>searchInStock(e),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().search_input_mobile),
                                        onChange: (e)=>setArticle(e.target.value),
                                        placeholder: "Введіть номер запчастини..."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "submit",
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().search_mobele_btn),
                                        children: !loading ? _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .search */ .XP : "---"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_main),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().select_part),
                                children: [
                                    _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .car */ .ZB,
                                    "Автозапчастини"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().search_container),
                                onSubmit: (e)=>searchInStock(e),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().search_input),
                                        onChange: (e)=>setArticle(e.target.value),
                                        placeholder: "Введіть номер запчастини..."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "submit",
                                        children: !loading ? "Пошук" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().dots_bars_4)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().basket_container),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/checkout",
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().basket_and_numbers),
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .newbasket */ .Aj,
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().near_basket_items),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            sumury,
                                                            " товарів"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().small_font),
                                                        children: "# роздріб"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().total_sum),
                                        children: [
                                            sumury2 === 0 ? "0" : sumury2,
                                            " грн"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().header_bottom),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().list_categories),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/olyva-zmazka--i-tehnichni",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .droplet */ .ZO,
                                            "Оливи та рідини"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/galmivna-systema",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .discbrake */ .FZ,
                                            "Гальма"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/systema-zapalyuvannya-rozzharyuvannya",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .fireIgn */ .V_,
                                            "Запалення"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/obigriv-kondytsioner",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .hodovaa */ .eq,
                                            "Опалення/конд"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/rulova-systema",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .remni */ .Eo,
                                            "Рульова система"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/kuzov-skladovi",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .accecories */ .iD,
                                            "Кузов"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/systema-vypusku-vpusku-povitrya",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .electric */ .tu,
                                            "Впуск/випуск"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/systemy-pidgotovky-podachi-palyva",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .tiress */ .Er,
                                            "Подача палива"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().category),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/categories/aksesuary-zasoby-po-doglyadu-dod.tovary",
                                        children: [
                                            _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .kuzov */ .ER,
                                            "Аксесуари"
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    noResults ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_NewNavbar_module_css__WEBPACK_IMPORTED_MODULE_7___default().no_result),
                        children: "Не знайдено такого артикулу. Перевірте будь ласка чи артикул вірно вказаний"
                    }) : null
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewNavbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3258);
/* harmony import */ var _features_cart_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5678);
/* harmony import */ var _features_cardata_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _features_cart_redux__WEBPACK_IMPORTED_MODULE_1__, _features_cardata_redux__WEBPACK_IMPORTED_MODULE_2__]);
([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _features_cart_redux__WEBPACK_IMPORTED_MODULE_1__, _features_cardata_redux__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        cartReducer: _features_cart_redux__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
        dataSelectscartReducer: _features_cardata_redux__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2581:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ ReduxProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _global_state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9847);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3291);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_global_state__WEBPACK_IMPORTED_MODULE_1__, react_redux__WEBPACK_IMPORTED_MODULE_2__]);
([_global_state__WEBPACK_IMPORTED_MODULE_1__, react_redux__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";




function ReduxProvider({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {
        store: _global_state__WEBPACK_IMPORTED_MODULE_1__/* .store */ .h,
        children: [
            " ",
            children,
            " "
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;