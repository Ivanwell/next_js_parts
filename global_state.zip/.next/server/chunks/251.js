exports.id = 251;
exports.ids = [251];
exports.modules = {

/***/ 251:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "How_to_order_main__8JHYJ",
	"main_page": "How_to_order_main_page__0jpqu",
	"cont_for_two_descr": "How_to_order_cont_for_two_descr__eXFm_",
	"describing": "How_to_order_describing__AovAA",
	"descr_cont": "How_to_order_descr_cont__tfeZQ",
	"request_form_cont": "How_to_order_request_form_cont__sscjd",
	"row_for_name_numberphone": "How_to_order_row_for_name_numberphone__HXdeJ",
	"input_name_phone": "How_to_order_input_name_phone__cPyhZ",
	"description_request": "How_to_order_description_request__SqM_Y",
	"description_question": "How_to_order_description_question__xGMLz",
	"input_vin": "How_to_order_input_vin__0GlDC",
	"input_part": "How_to_order_input_part__OZixx",
	"input_question": "How_to_order_input_question__iKfKF",
	"submit_button": "How_to_order_submit_button__AcXm5",
	"input_vin_mobile": "How_to_order_input_vin_mobile__DQACK",
	"submit_button_mobile": "How_to_order_submit_button_mobile__vtLOM"
};


/***/ })

};
;