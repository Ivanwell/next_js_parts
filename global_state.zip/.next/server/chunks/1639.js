"use strict";
exports.id = 1639;
exports.ids = [1639];
exports.modules = {

/***/ 1639:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HB": () => (/* binding */ setBrand),
/* harmony export */   "PR": () => (/* binding */ setCategory),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "_1": () => (/* binding */ setDataForForm),
/* harmony export */   "dm": () => (/* binding */ setLoadingData),
/* harmony export */   "j1": () => (/* binding */ setModel),
/* harmony export */   "rx": () => (/* binding */ setPart)
/* harmony export */ });
/* unused harmony export dataSelects */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3258);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__]);
_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const initialState = {
    value: {
        dataForSelects: null,
        brand: null,
        model: null,
        category: null,
        part: null,
        loading: false
    }
};
const dataSelects = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "dataSelects",
    initialState: initialState,
    reducers: {
        setDataForForm: (state, action)=>{
            state.value.dataForSelects = action.payload;
        },
        setBrand: (state, action)=>{
            if (action.payload === "Оберіть марку") {
                state.value.brand = null;
                state.value.model = null;
                state.value.category = null;
                state.value.part = null;
            } else {
                state.value.brand = action.payload;
            }
        },
        setModel: (state, action)=>{
            if (action.payload === "Оберіть модель") {
                state.value.model = null;
                state.value.category = null;
                state.value.part = null;
            } else {
                state.value.model = action.payload;
            }
        },
        setCategory: (state, action)=>{
            if (action.payload === "Оберіть категорію") {
                state.value.category = null;
                state.value.part = null;
            } else {
                state.value.category = action.payload;
            }
        },
        setPart: (state, action)=>{
            if (action.payload === "Оберіть запчастину") {
                state.value.part = null;
            } else {
                state.value.part = action.payload;
            }
        },
        setLoadingData: (state, action)=>{
            state.value.loading = action.payload;
        }
    }
});
const { setDataForForm , setBrand , setModel , setCategory , setPart , setLoadingData  } = dataSelects.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dataSelects.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;