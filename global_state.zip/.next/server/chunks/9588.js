exports.id = 9588;
exports.ids = [9588];
exports.modules = {

/***/ 6765:
/***/ ((module) => {

// Exports
module.exports = {
	"compatib_cont": "Compatibility_compatib_cont__s5T_7",
	"one_brand_cont": "Compatibility_one_brand_cont__oroW5",
	"one_brand_title": "Compatibility_one_brand_title__SzOBs",
	"one_brand_models": "Compatibility_one_brand_models__vIHdC",
	"one_brand_model": "Compatibility_one_brand_model__DV_0V",
	"title_model": "Compatibility_title_model__97xPw",
	"one_model_engines": "Compatibility_one_model_engines__sp_gY"
};


/***/ }),

/***/ 591:
/***/ ((module) => {

// Exports
module.exports = {
	"nodisplay": "NewItem_nodisplay__66sR2",
	"main_item": "NewItem_main_item__BIPm_",
	"container_item_desctop": "NewItem_container_item_desctop__miRaG",
	"container_image": "NewItem_container_image__TaZAV",
	"brand_title": "NewItem_brand_title__OSQsO",
	"informaton_container": "NewItem_informaton_container__cVOUj",
	"main_item_atcile": "NewItem_main_item_atcile__tROrT",
	"main_item_title": "NewItem_main_item_title__p3TUy",
	"main_item_details": "NewItem_main_item_details__0WEha",
	"item_detail_row": "NewItem_item_detail_row___AFCG",
	"details_new_btn": "NewItem_details_new_btn__7FgOc",
	"returning_cont": "NewItem_returning_cont__MzgUS",
	"returning_cont_new": "NewItem_returning_cont_new__lp9Si",
	"loader": "NewItem_loader__VonmZ",
	"shadowRolling": "NewItem_shadowRolling__pq0Vw",
	"purchaise_container": "NewItem_purchaise_container__W8Dav",
	"whole_image_cont": "NewItem_whole_image_cont__G46S3",
	"wishlist_and_stock": "NewItem_wishlist_and_stock__JUQ31",
	"svg_and_title": "NewItem_svg_and_title__vJQwb",
	"price_container": "NewItem_price_container__tgQYi",
	"empty_name_phone": "NewItem_empty_name_phone__Q5EEm",
	"price_container_with_disc": "NewItem_price_container_with_disc__o4mTq",
	"old_price_and_disc_cont": "NewItem_old_price_and_disc_cont__3FA7l",
	"old_price": "NewItem_old_price__8E0aV",
	"disc_container": "NewItem_disc_container__Jugds",
	"real_price": "NewItem_real_price__5Hq6b",
	"deliver_cost": "NewItem_deliver_cost__pDDrD",
	"aviability_cont": "NewItem_aviability_cont__rE8gC",
	"last_item_cont": "NewItem_last_item_cont___VQTQ",
	"cart_full": "NewItem_cart_full__sKoBB",
	"add_remove_items_container": "NewItem_add_remove_items_container__kYAvA",
	"add_remove_btn": "NewItem_add_remove_btn__GOk0W",
	"added_items": "NewItem_added_items__cWtTg",
	"buy_btn": "NewItem_buy_btn__t2Wgs",
	"buy_btn_check": "NewItem_buy_btn_check__JDlGa",
	"cont_for_oem_and_compability": "NewItem_cont_for_oem_and_compability__LaKS0",
	"non_info": "NewItem_non_info__a14rC",
	"cont_for_oem_title": "NewItem_cont_for_oem_title__XP_SL",
	"cont_for_oem_numbers": "NewItem_cont_for_oem_numbers__aTwWf",
	"number_and_brand": "NewItem_number_and_brand__omojF",
	"container_for_question": "NewItem_container_for_question__nc_9I",
	"request_form_cont": "NewItem_request_form_cont__zUHZN",
	"request_form_cont_new": "NewItem_request_form_cont_new__rxjzD",
	"row_for_name_numberphone": "NewItem_row_for_name_numberphone__kj8RX",
	"input_name_phone": "NewItem_input_name_phone__XPgEs",
	"description_request": "NewItem_description_request__EVBE3",
	"description_question": "NewItem_description_question__L4eb3",
	"input_vin": "NewItem_input_vin__dMPfT",
	"input_question": "NewItem_input_question__nVcl7",
	"submit_button": "NewItem_submit_button__eNzCo",
	"more_button": "NewItem_more_button__xjjpM",
	"container_item_mobile": "NewItem_container_item_mobile__DqIRj",
	"detail_cont_new": "NewItem_detail_cont_new__n0kNT",
	"input_vin_desctop": "NewItem_input_vin_desctop__R3iju",
	"submit_button_desctop": "NewItem_submit_button_desctop__eE5OX",
	"searched_car_mobile": "NewItem_searched_car_mobile__r_4Y4",
	"searched_check_needed_desc": "NewItem_searched_check_needed_desc__v5IAr",
	"input_phone_desctop": "NewItem_input_phone_desctop__n05S9",
	"container_item": "NewItem_container_item__Z66fT",
	"detail_cont_mobile": "NewItem_detail_cont_mobile__AqMMV",
	"go_back_cont": "NewItem_go_back_cont__KVlPK",
	"top_info_mobile": "NewItem_top_info_mobile__tLMCT",
	"article_mobile": "NewItem_article_mobile___lOIU",
	"image_mobile": "NewItem_image_mobile__g0kK0",
	"price_info_cont": "NewItem_price_info_cont__jS9wF",
	"stock_info_cont": "NewItem_stock_info_cont__v6gIo",
	"in_stock_info": "NewItem_in_stock_info__GkIfh",
	"out_stock_info": "NewItem_out_stock_info__2_wOF",
	"amount_info": "NewItem_amount_info__TGZsx",
	"price_info_column": "NewItem_price_info_column__6J_2a",
	"price": "NewItem_price__8gU0E",
	"delivery": "NewItem_delivery__fr_X0",
	"newpostimg": "NewItem_newpostimg__LwroV",
	"buttons_container": "NewItem_buttons_container__V6BOr",
	"add_remove_btns_container": "NewItem_add_remove_btns_container__uvwvL",
	"add_remove_btns": "NewItem_add_remove_btns__8E_ev",
	"buy_button_mobile": "NewItem_buy_button_mobile__aqBqa",
	"check_button_mobile": "NewItem_check_button_mobile__5eO__",
	"check_button_mobile_opened": "NewItem_check_button_mobile_opened__drstz",
	"return_container": "NewItem_return_container__bNT0d",
	"returning_mobile": "NewItem_returning_mobile__qLqgr",
	"detal_title_mobile": "NewItem_detal_title_mobile__tM5ir",
	"icon_and_name": "NewItem_icon_and_name__H6PfB",
	"info_container": "NewItem_info_container__3npVc",
	"center": "NewItem_center__ro5Fj",
	"detail_key": "NewItem_detail_key__Si8qI",
	"detail_value": "NewItem_detail_value__wBex7",
	"detal_title_mobile_form": "NewItem_detal_title_mobile_form__dWE_2",
	"input_vin_mobile": "NewItem_input_vin_mobile__Dniza",
	"submit_button_mobile": "NewItem_submit_button_mobile__Ddep3",
	"searched_check_needed": "NewItem_searched_check_needed__Z4KCe"
};


/***/ }),

/***/ 9093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6765);
/* harmony import */ var _styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4761);




const Engines = ({ engines  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().one_model_engines),
        children: engines.map((engine)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: engine.engine
            }))
    });
};
const OneModel = ({ model  })=>{
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().title_model),
                onClick: ()=>setIsVisible((prev)=>!prev),
                children: [
                    _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .rightArrow */ .eE,
                    model.model
                ]
            }),
            isVisible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Engines, {
                engines: model.engines
            }) : null
        ]
    });
};
const Models = ({ models  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().one_brand_models),
        children: models.map((model)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().one_brand_model),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OneModel, {
                    model: model
                })
            }))
    });
};
const OneBrand = ({ brand  })=>{
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().one_brand_cont),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().one_brand_title),
                onClick: ()=>setIsVisible((prev)=>!prev),
                children: [
                    _SVGs_SVGs__WEBPACK_IMPORTED_MODULE_2__/* .rightArrow */ .eE,
                    brand.brand
                ]
            }),
            isVisible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Models, {
                models: brand.models
            }) : null
        ]
    });
};
const Compatibility = ({ fits  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Compatibility_module_css__WEBPACK_IMPORTED_MODULE_3___default().compatib_cont),
        children: fits.map((brand)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OneBrand, {
                brand: brand
            }))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Compatibility);


/***/ }),

/***/ 5881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ event),
/* harmony export */   "LV": () => (/* binding */ pageview)
/* harmony export */ });
/* unused harmony export GA_TRACKING_ID */
const GA_TRACKING_ID = "G-6SSFMSDB43";
const pageview = (url)=>{
    window.gtag("config", GA_TRACKING_ID, {
        page_path: url
    });
};
const event = ({ action , params  })=>{
    window.gtag("event", action, params);
};


/***/ })

};
;