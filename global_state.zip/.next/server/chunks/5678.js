"use strict";
exports.id = 5678;
exports.ids = [5678];
exports.modules = {

/***/ 5678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O3": () => (/* binding */ adddToCart),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zd": () => (/* binding */ handleOpenPropToCheck),
/* harmony export */   "an": () => (/* binding */ deleteAllItems),
/* harmony export */   "nO": () => (/* binding */ removeOneItemRe),
/* harmony export */   "nf": () => (/* binding */ showFullImage),
/* harmony export */   "nu": () => (/* binding */ hideFullImage)
/* harmony export */ });
/* unused harmony export cart */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3258);
/* harmony import */ var _components_lib_gtag__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__]);
_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    value: {
        list: [],
        total: 0,
        sum: 0,
        openedCheckoutProposal: false,
        imgCont: {
            visibility: false,
            image: null
        }
    }
};
const cart = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState: initialState,
    reducers: {
        adddToCart: (state, action)=>{
            const check = state.value.list.findIndex((item)=>item.article === action.payload.article);
            console.log(action.payload);
            if (check !== -1) {
                state.value.list[check].quantity += action.payload.quantity;
            } else {
                state.value.list.push(action.payload);
                _components_lib_gtag__WEBPACK_IMPORTED_MODULE_1__/* .event */ .B({
                    action: "add_to_cart"
                });
                state.value.openedCheckoutProposal = true;
            }
            state.value.total += action.payload.quantity;
            state.value.sum += action.payload.price * action.payload.quantity;
        },
        removeOneItemRe: (state, action)=>{
            const check = state.value.list.findIndex((item)=>item.article === action.payload.article);
            if (check === -1) {
                return;
            } else {
                if (state.value.list[check].quantity === 1) {
                    state.value.list.splice(check, 1);
                } else {
                    state.value.list[check].quantity -= 1;
                }
                state.value.total -= 1;
                state.value.sum -= action.payload.price;
            }
        },
        removeWholeItem: (state, action)=>{
            const check = state.value.list.findIndex((item)=>item.article === action.payload.article);
            if (check === -1) {
                return;
            } else {
                state.value.total -= action.payload.quantity;
                state.value.sum -= action.payload.price * action.payload.quantity;
                state.value.list.splice(check, 1);
            }
        },
        handleOpenPropToCheck: (state, action)=>{
            state.value.openedCheckoutProposal = action.payload;
        },
        deleteAllItems: (state, action)=>{
            ;
            state.value.total = 0, state.value.sum = 0, state.value.list = [];
        },
        showFullImage: (state, action)=>{
            state.value.imgCont = {
                visibility: true,
                image: action.payload
            };
        },
        hideFullImage: (state, action)=>{
            state.value.imgCont = {
                visibility: false,
                image: null
            };
        }
    }
});
const { adddToCart , removeOneItemRe , handleOpenPropToCheck , deleteAllItems , showFullImage , hideFullImage  } = cart.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cart.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;