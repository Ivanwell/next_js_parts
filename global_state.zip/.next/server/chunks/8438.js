exports.id = 8438;
exports.ids = [8438];
exports.modules = {

/***/ 3119:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Contacts_main__U0vyj",
	"whole_cont": "Contacts_whole_cont__Mv3QE",
	"smaller_cont": "Contacts_smaller_cont__tPP9g",
	"greenwall": "Contacts_greenwall__mvl7T",
	"main_page": "Contacts_main_page____ZHF",
	"massengers_container_main": "Contacts_massengers_container_main__MWHRA",
	"massengers_container": "Contacts_massengers_container__Qo4ZF",
	"viberBtn": "Contacts_viberBtn__a0iAI",
	"telegramrBtn": "Contacts_telegramrBtn__mplKU",
	"viberSVG": "Contacts_viberSVG__Ui2e_",
	"telegramSVG": "Contacts_telegramSVG__aaPme",
	"whole_search_container": "Contacts_whole_search_container__mf0qN",
	"search_container": "Contacts_search_container__Uq4Gm",
	"left_container": "Contacts_left_container__0v3GH",
	"search_model_cont": "Contacts_search_model_cont__4a2NN",
	"search_result_cont": "Contacts_search_result_cont__dMk4d",
	"request_form_cont": "Contacts_request_form_cont__f3m0j",
	"row_for_name_numberphone": "Contacts_row_for_name_numberphone__UA2Y4",
	"input_name_phone": "Contacts_input_name_phone__wBGEc",
	"description_request": "Contacts_description_request__yKNLI",
	"description_question": "Contacts_description_question__mX1vM",
	"input_vin": "Contacts_input_vin__ufOGz",
	"input_part": "Contacts_input_part__mIO64",
	"input_question": "Contacts_input_question__uerF3",
	"submit_button": "Contacts_submit_button__breiS",
	"call_me_btn_contacts": "Contacts_call_me_btn_contacts__C1MTI",
	"input_vin_mobile": "Contacts_input_vin_mobile___cvH3",
	"submit_button_mobile": "Contacts_submit_button_mobile__gih1Y"
};


/***/ }),

/***/ 5881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ event),
/* harmony export */   "LV": () => (/* binding */ pageview)
/* harmony export */ });
/* unused harmony export GA_TRACKING_ID */
const GA_TRACKING_ID = "G-6SSFMSDB43";
const pageview = (url)=>{
    window.gtag("config", GA_TRACKING_ID, {
        page_path: url
    });
};
const event = ({ action , params  })=>{
    window.gtag("event", action, params);
};


/***/ })

};
;