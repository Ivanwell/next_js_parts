exports.id = 2777;
exports.ids = [2777];
exports.modules = {

/***/ 2646:
/***/ ((module) => {

// Exports
module.exports = {
	"whole_search_container": "NewSearch_whole_search_container__LZaF4",
	"search_container": "NewSearch_search_container__1GnOV",
	"nosearch_container": "NewSearch_nosearch_container__soenO",
	"search_model_cont": "NewSearch_search_model_cont__p2Jo9",
	"search_result_cont": "NewSearch_search_result_cont__xYz0P",
	"search_result_cont_mobile": "NewSearch_search_result_cont_mobile__vHkU6",
	"search_results": "NewSearch_search_results__v0op3",
	"searched_item": "NewSearch_searched_item__AdNss",
	"img_cont": "NewSearch_img_cont__c4Tmv",
	"brand_up_photo": "NewSearch_brand_up_photo___pay1",
	"last_item_cont": "NewSearch_last_item_cont__UBZgo",
	"main_info_product": "NewSearch_main_info_product__oJGBv",
	"top_name_item": "NewSearch_top_name_item__i8180",
	"artilce": "NewSearch_artilce__lB5z6",
	"title_prod_info": "NewSearch_title_prod_info__I0H_C",
	"prod_info": "NewSearch_prod_info__FPGam",
	"purchaise_info": "NewSearch_purchaise_info__BgacS",
	"add_to_wish_list": "NewSearch_add_to_wish_list__wvOUY",
	"price_container": "NewSearch_price_container__HqXUN",
	"old_price_and_disc_cont": "NewSearch_old_price_and_disc_cont__Q0uZ7",
	"old_price": "NewSearch_old_price__bZe1U",
	"real_price": "NewSearch_real_price__EGJXV",
	"deliver_cost": "NewSearch_deliver_cost__mzRjC",
	"aviability_cont": "NewSearch_aviability_cont__GBVyF",
	"aviability_cont_out": "NewSearch_aviability_cont_out__cF_eo",
	"how_many_available": "NewSearch_how_many_available__Kfye0",
	"byu_btn_search": "NewSearch_byu_btn_search__RVWVS",
	"ckeck_aviability": "NewSearch_ckeck_aviability__4xJI_",
	"add_min_btn_cont": "NewSearch_add_min_btn_cont__qNns_",
	"disc_container": "NewSearch_disc_container__VOHyX",
	"search_form": "NewSearch_search_form__TslNk",
	"container_search_form": "NewSearch_container_search_form__jnykT",
	"select_car_title": "NewSearch_select_car_title__cYKvo",
	"select_container": "NewSearch_select_container__rYwu3",
	"number": "NewSearch_number__8ldIO",
	"search_button": "NewSearch_search_button__O85z2",
	"cannot_find_part": "NewSearch_cannot_find_part__52bfP",
	"cannot_find_part_title": "NewSearch_cannot_find_part_title__xMx6y",
	"no_search_result": "NewSearch_no_search_result__AnaN5",
	"img_container": "NewSearch_img_container__EAIvw",
	"no_res_description": "NewSearch_no_res_description__QFuaw",
	"go_back_cont": "NewSearch_go_back_cont__BLLmL",
	"search_results_mobile": "NewSearch_search_results_mobile__nVtgw",
	"separate_item_cont": "NewSearch_separate_item_cont__jDXYN",
	"top_item": "NewSearch_top_item__X2wMp",
	"add_wishlist": "NewSearch_add_wishlist__MKdhg",
	"main_container_info_mobile": "NewSearch_main_container_info_mobile__5_X3U",
	"cont_for_img_and_info": "NewSearch_cont_for_img_and_info__rQsZc",
	"main_img_container": "NewSearch_main_img_container__mi3IV",
	"main_info": "NewSearch_main_info__fkaLB",
	"buttons_cont": "NewSearch_buttons_cont__ske1r",
	"detail_button": "NewSearch_detail_button__8NTL_",
	"add_remove_btns_container": "NewSearch_add_remove_btns_container__E4U6B",
	"add_remove_btns": "NewSearch_add_remove_btns___VwOD",
	"byu_btn_mobile": "NewSearch_byu_btn_mobile___Ex6N"
};


/***/ }),

/***/ 5881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ event),
/* harmony export */   "LV": () => (/* binding */ pageview)
/* harmony export */ });
/* unused harmony export GA_TRACKING_ID */
const GA_TRACKING_ID = "G-6SSFMSDB43";
const pageview = (url)=>{
    window.gtag("config", GA_TRACKING_ID, {
        page_path: url
    });
};
const event = ({ action , params  })=>{
    window.gtag("event", action, params);
};


/***/ }),

/***/ 2741:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._extends = _extends;
function _extends() {
    exports._ = exports._extends = _extends = Object.assign || function assign(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
        }

        return target;
    };

    return _extends.apply(this, arguments);
}


/***/ }),

/***/ 167:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


exports._ = exports._interop_require_default = _interop_require_default;
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
}


/***/ })

};
;